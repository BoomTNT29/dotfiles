#include <bits/stdc++.h>

using namespace std;

int twoStacks(int x, vector<int> a, vector<int> b)
{
    int sum = 0, i = 0, j = 0, ii = a.size(), jj = b.size(), cnt = 0;

    while (i < ii && sum + a[i] <= x) // i is less than size of stack and sum is less than the maxSum
        sum += a[i++];                // calc sum
    
    cnt = i;
    while (i >= 0 && j < jj)    // while i is not negeative, 
    {
        sum += b[j++];
    
        while (sum > x && i > 0)
            sum -= a[--i];
    
        if (sum <= x && (i + j) > cnt)
            cnt = i + j;
    }
    
    return cnt;
}