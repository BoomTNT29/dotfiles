Addi $t0, $s6, 4
add $t1, $s6, $0
BEQ $t0, $t1, next 
sw $t1, 0($t0)
lw $s0, 0($t0)
next: add $s0, $s1, $t0