# this sample code for MIPS

.data

msg1:	.ascii "this is my message"

.text

__start:

	la $t0,msg1      	# this is a comment
	lw $t1,0($t0)
	
	addi $t1,$t1,48     	# commands are blue
				# variables are red
				# constants are black.
