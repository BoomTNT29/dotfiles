#Written by Harshith(IMT2017516)
#email: Harshith.Reddy@iiitb.org

#run in linux terminal by java -jar Mars4_5.jar nc filename.asm(take inputs from console)

#system calls by MARS simulator:
#http://courses.missouristate.edu/kenvollmar/mars/help/syscallhelp.html
.data
	next_line: .asciiz "\n"	
.text
#input: no. numbers to sort and stored in $t1	
jal input_int 
move $t1,$t4			

#input: Starting address of numbers to be stored(each 32bits) in decimal stored in $t2
jal input_int
move $t2,$t4

#input: ending address of numbers to be stored(each 32bits) in decimal stored in $t3
jal input_int
move $t3,$t4 

#input: numbers to sort stored in memory array starting address given by $t2
move $t8,$t2
move $s7,$zero	#i = 0
loop1:  beq $s7,$t1,loop1end
	jal input_int
	sw $t4,0($t2)
	addi $t2,$t2,4
      	addi $s7,$s7,1
        j loop1      
loop1end: move $t2,$t8       

#Occupied registers $t1,$t2,$t3 don't use them in your sort function.
#function: should be written by students(sorting two
lw $s3,0($t2)
addi $s3,$s3,10
sw $s3,0($t3)
lw $s3,4($t2)
addi $s3,$s3,10
sw $s3,4($t3)
#endfunction

#print sorted numbers
move $s7,$zero	#i = 0
loop: beq $s7,$t1,end
      lw $t4,0($t3)
      jal print_int
      jal print_line
      addi $t3,$t3,4
      addi $s7,$s7,1
      j loop 
#end
end:  li $v0,10
      syscall
#input from command line(takes input and stores it in $t6)
input_int: li $v0,5
	   syscall
	   move $t4,$v0
	   jr $ra
#print integer(prints the value of $t6 )
print_int: li $v0,1		#1 implie
	   move $a0,$t4
	   syscall
	   jr $ra
#print nextline
print_line:li $v0,4
	   la $a0,next_line
	   syscall
	   jr $ra

