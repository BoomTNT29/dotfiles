.text	
	
	j main
	
	fact:
		addi	$sp, $sp, -8
		sw	$a0, 0($sp)
		sw	$ra, 4($sp)
		
		slti 	$t1, $a0, 1
		beq	$t1, 0, jmp
		
		addi 	$sp, $sp, 8
		addi	$v0, $zero, 1
		jr	$ra
		
		jmp:
		addi	$a0, $a0, -1
		jal	fact
		
		lw	$a0, 0($sp)
		lw	$ra, 4($sp)
		addi	$sp, $sp, 8
		mul	$v0, $a0, $v0
		jr	$ra
	
	main:
		addi	$v0, $zero, 5
			syscall
		add	$a0, $zero, $v0
		jal	fact
		add	$a0, $zero, $v0
		addi	$v0, $zero, 1
			syscall