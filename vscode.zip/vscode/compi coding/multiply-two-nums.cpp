#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << x << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

string add_st(string &s1, string &s2)
{
    string ans;
    int p1 = 0, p2 = 0, carry = 0;

    while (p1 < s1.size() && p2 < s2.size())
    {
        carry += (s1[p1] - '0') + (s2[p2] - '0');
        ans += ('0' + carry % 10);
        carry /= 10;
        p1++, p2++;
    }

    while (p1 < s1.size())
    {
        carry += (s1[p1] - '0');
        ans += ('0' + carry % 10);
        carry /= 10;
        p1++;
    }

    while (p2 < s2.size())
    {
        carry += (s2[p2] - '0');
        ans += ('0' + carry % 10);
        carry /= 10;
        p2++;
    }

    string temp2;
    while (carry)
    {
        temp2 += carry % 10 + '0';
        carry /= 10;
    }

    ans += temp2;

    return ans;
}

void solve(void)
{
    string s1, s2;
    cin >> s1 >> s2;

    reverse(all(s1));
    reverse(all(s2));

    string final_ans = "00";

    fr(i, s1.size())
    {
        int temp = 0;
        string k;
        fr(x, i)
            k += '0';
        fr(j, s2.size())
        {
            temp += (s1[i] - '0') * (s2[j] - '0');
            k += temp % 10 + '0';
            temp /= 10;
        }
        string temp2;
        while (temp)
        {
            temp2 += temp % 10 + '0';
            temp /= 10;
        }
        reverse(all(temp2));
        k += temp2;
        final_ans = add_st(k, final_ans);
    }

    reverse(all(final_ans));
    cout << final_ans;
    nl;
}

int main(void)
{
    fast_io;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}