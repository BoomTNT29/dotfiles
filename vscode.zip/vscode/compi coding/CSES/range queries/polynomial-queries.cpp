#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

struct item
{
    ll value, lazyx, lazyd;
};

struct segTree
{
    ll size;
    vector<item> values;

    void init(ll n)
    {
        size = 1;
        while (size < n)
            size *= 2;
        values.resize(size * 2);
    }

    void build(vector<ll> v)
    {
        for (ll i = 0; i < (ll)v.size(); i++)
            values[size - 1 + i] = {v[i], 0, 0};

        for (ll i = size - 2; i > -1; i--)
            values[i] = {values[2 * i + 1].value + values[2 * i + 2].value, 0, 0};
    }

    void updateLazy(ll ss, ll se, ll m, ll i)
    {
        values[i].value += ((ll)(se - ss + 1)) * values[i].lazyx + ((ll)(((se - ss) * (se - ss + 1)) / 2)) * values[i].lazyd;

        if (ss != se)
        {
            values[2 * i + 1].lazyx += values[i].lazyx;
            values[2 * i + 1].lazyd += values[i].lazyd;

            values[2 * i + 2].lazyx += values[i].lazyx + values[i].lazyd * ((ll)(m - ss + 1));
            values[2 * i + 2].lazyd += values[i].lazyd;
        }

        values[i].lazyd = (ll)0;
        values[i].lazyx = (ll)0;
    }

    void updateRange(ll x, ll d, ll l, ll r, ll ss, ll se, ll i)
    {
        ll m = (ss + se) / 2;

        if (values[i].lazyd != 0 || values[i].lazyx != 0)
            updateLazy(ss, se, m, i);

        if (se < l || r < ss)
            return;

        if (l <= ss && r >= se)
        {
            values[i].lazyx += (ll)(x + (ss - l) * d);
            values[i].lazyd += (ll)d;
            updateLazy(ss, se, m, i);
            return;
        }

        updateRange(x, d, l, r, ss, m, 2 * i + 1);
        updateRange(x, d, l, r, m + 1, se, 2 * i + 2);

        values[i].value = values[2 * i + 1].value + values[2 * i + 2].value;
    }

    void updateRange(ll x, ll d, ll l, ll r)
    {
        updateRange(x, d, l, r, 0, size - 1, 0);
    }

    ll rangeSum(ll l, ll r, ll ss, ll se, ll i)
    {
        ll m = (ss + se) / 2;

        if (values[i].lazyd != 0 || values[i].lazyx != 0)
            updateLazy(ss, se, m, i);

        if (l > se || r < ss)
            return 0;

        if (l <= ss && r >= se)
            return values[i].value;

        return rangeSum(l, r, ss, m, 2 * i + 1) + rangeSum(l, r, m + 1, se, 2 * i + 2);
    }

    ll rangeSum(ll l, ll r)
    {
        return rangeSum(l, r, 0, size - 1, 0);
    }

    ll realSum(ll l, ll r)
    {
        ll s = 0;
        for (ll i = l; i <= r; i++)
            s += rangeSum(i, i);

        return s;
    }
};

int main(void)
{
    ll n, q;
    cin >> n >> q;

    segTree st;
    st.init(n);
    vector<ll> v(n);

    for (auto &x : v)
        cin >> x;

    st.build(v);

    ll t, l, r;
    for (ll i = 0; i < q; i++)
    {
        cin >> t >> l >> r;
        l--, r--;
        if (t == 1)
        {
            st.updateRange((ll)1, (ll)1, l, r);
        }
        if (t == 2)
        {
            // cout << st.realSum(l, r) << endl;
            cout << st.rangeSum(l, r) << endl;
        }

        // for (ll i = 0; i < n; i++)
        //     cout << st.rangeSum(i, i) << ' ';
        // cout << endl
        //      << endl;
    }
}