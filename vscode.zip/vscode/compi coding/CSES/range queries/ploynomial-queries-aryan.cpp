#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;

class Node
{
    public:
    ll sum = 0;
    ll constTerm = 0;
    ll additiveTerm = 0;
    ll length = 0;

    void update(ll x, ll d)
    {
        constTerm += x;
        additiveTerm += d;
        sum += x * length + (d) * (length * length - length) / 2;
    }

    void set(ll val)
    {
        sum = val;
        constTerm = 0;
        additiveTerm = 0;
    }

    void print()
    {
        cout << sum << " " << constTerm << " " << additiveTerm << " " << length << endl;
    }
};

int leaves = 0;
vector<Node> buildTree(vector<int> & vec)
{
    double temp = log(vec.size()) / log(2);

    if(temp == (int)(temp))
        leaves = 1 << (int)(temp);
    else
        leaves = 1 << (int)(temp + 1);
    
    int n = 2 * leaves - 1;

    vector<Node> nodes;

    for(int i = 0; i < n; i++)
        nodes.push_back(Node());

    for(int i = 0; i < vec.size(); i++)
    {
        nodes[i + leaves - 1].sum = vec[i];
    }

    for(int i = leaves - 1; i < n; i++)
        nodes[i].length = 1;

    for(int i = leaves - 2; i >= 0; i--)
    {
        nodes[i].sum = nodes[2 * i + 1].sum + nodes[2 * i + 2].sum;
        nodes[i].length = nodes[2 * i + 1].length + nodes[2 * i + 2].length;
    }

    return nodes;
}

ll update(vector<Node> & ST, int l, int r, int i, int SS, int SE, ll x, ll d)
{
    if(l <= SS && SE <= r)
    {
        ST[i].update(x, d);
        return ST[i].length;
    }
    else if(SE < l || SS > r)
        return 0;
    else
    {
        int mid = (SS + SE) / 2;

        ST[2 * i + 1].update(ST[i].constTerm, ST[i].additiveTerm);
        ST[2 * i + 2].update(ST[i].constTerm + (SE - mid - 1 + 1) * ST[i].additiveTerm, ST[i].additiveTerm);

        ll left = update(ST, l, r, 2 * i + 1, SS, mid, x, d);
        ll right = update(ST, l, r, 2 * i + 2, mid + 1, SE, x + left * d, d);

        ST[i].set(ST[2 * i + 1].sum + ST[2 * i + 2].sum);

        return left + right;
    }
}

ll findAns(vector<Node> & ST, int l, int r, int i, int SS, int SE)
{
    if(l <= SS && SE <= r)
        return ST[i].sum;
    else if(SE < l || SS > r)
        return 0;
    else
    {
        int mid = (SS + SE) / 2;

        ll c = ST[i].constTerm;
        ll a = ST[i].additiveTerm;

        ST[2 * i + 1].update(c, a);
        ST[2 * i + 2].update(c + a * (SE - mid - 1 + 1), a);

        ll val = findAns(ST, l, r, 2 * i + 1, SS, mid) + findAns(ST, l, r, 2 * i + 2, mid + 1, SE);
        ST[i].set(ST[2 * i + 1].sum + ST[2 * i + 2].sum);

        return val;
    }
}

void print(vector<Node> & ST)
{
    for(Node n : ST)
        n.print();
}

int main()
{
    ios_base::sync_with_stdio(false);

    int n, q;
    cin >> n >> q;   

    vector<int> vec(n);
    for(int i = 0; i < n; i++)
    {
        int num;
        cin >> num;
        vec[i] = num;
    }

    vector<Node> ST = buildTree(vec);

    //print(ST);

    for(int i = 0; i < q; i++)
    {
        int type, a, b;
        cin >> type >> a >> b;

        if(type == 1)
            update(ST, a - 1, b - 1, 0, 0, leaves - 1, 1, 1);
        else
            cout << findAns(ST, a - 1, b - 1, 0, 0, leaves - 1) << endl;
        
        //print(ST);
    }
    
    return 0;
}