#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void read_adjList_dg(vector<vector<ll>> &adj_list, int m) // its stored in the pair as node, wt
{
    ll s, t;
    for (int i = 0; i < m; i++)
    {
        cin >> s >> t;
        adj_list[s - 1].push_back(t - 1);
        adj_list[t - 1].push_back(s - 1);
    }
}

void DFS(vector<vector<ll>> &adj_list, vector<ll> &v, ll parent, ll src, vector<ll> &included, vector<ll> &excluded)
{
    v[src] = 1;

    for (auto x : adj_list[src])
    {
        if (v[x] == 0)
        {
            DFS(adj_list, v, src, x, included, excluded);
            excluded[src] += max(included[x], excluded[x]);
        }
    }

    for (auto x : adj_list[src])
    {
        if (parent != x)
        {
            included[src] = max(included[src], max(excluded[src], excluded[src] - max(included[x], excluded[x]) + excluded[x] + 1));
        }
    }
}

void solve(void)
{
    int n = 1;
    cin >> n;

    vector<vector<ll>> adj_list(n);
    read_adjList_dg(adj_list, n - 1);

    vector<ll> v(n, 0), p(n, 0), included(n, 0), excluded(n, 0);
    DFS(adj_list, v, -1, 0, included, excluded);

    // dbgv(included, ' ');
    // nl;
    // dbgv(excluded, ' ');
    // nl;

    cout << max(excluded[0], included[0]) << endl;
}

int main(void)
{
    fast_io;

    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}