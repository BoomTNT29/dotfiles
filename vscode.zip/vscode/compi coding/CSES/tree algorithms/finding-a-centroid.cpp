#include <bits/stdc++.h>

using namespace std;

struct graph
{
    int size;
    vector<vector<int>> conn;
    vector<int> count;

    void init(int n)
    {
        size = n;
        conn.assign(n, {});
        count.assign(n, 0);
    }

    void dfs1(int vertex, int parent)
    {
        count[vertex] = 1;
        for (auto x : conn[vertex])
        {
            if (x != parent)
            {
                dfs1(x, vertex);
                count[vertex] += count[x];
            }
        }
    }

    int dfs2(int vertex, int parent)
    {
        if (parent != -1)
            count[parent] = size - count[vertex];

        bool flag = true;
        for (auto x : conn[vertex])
            if (count[x] > size / 2)
            {
                flag = false;
                break;
            }

        if (flag)
            return vertex;

        int ans;
        for (auto x : conn[vertex])
            if (x != parent)
                if ((ans = dfs2(x, vertex)) != -1)
                    return ans;

        return -1;
    }

    int run()
    {
        dfs1(0, -1);
        return dfs2(0, -1);
    }
};

int main(void)
{
    int n;
    cin >> n;

    graph gg;
    gg.init(n);

    int l, r;
    for (int i = 1; i < n; i++)
    {
        cin >> l >> r;
        l--, r--;

        gg.conn[l].push_back(r);
        gg.conn[r].push_back(l);
    }

    cout << gg.run() + 1 << endl;
}