#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

vector<ll> dijkstras(vector<vector<pair<ll, ll>>> adj_list, ll n, ll source) // returns array containing the least weighted paths from source
{
    vector<ll> vis(n), d(n, LLONG_MAX);

    priority_queue<pair<ll, ll>, vector<pair<ll, ll>>, greater<pair<ll, ll>>> pq;

    pq.emplace(0, source); // wt, vertex
    d[source] = 0;

    while (!pq.empty())
    {
        ll u = pq.top().second; // this node is optimised from source
        pq.pop();

        if (vis[u] == 0) // need to ignore duplicate nodes
        {
            vis[u] = 1;
            for (auto x : adj_list[u])
            {
                ll v = x.first; // need to optimise this node now
                ll wt = x.second;

                if (d[v] > d[u] + wt) // checking if this edge relaxes an already calculated distance
                {
                    d[v] = d[u] + wt;
                    pq.emplace(d[v], v); // pushing if it does
                }
            }
        }
    }

    return d;
}

int main(void)
{
    ll n, m;
    cin >> n >> m;

    vector<vector<pair<ll, ll>>> adj_list(n), rev_adj(n);
    for (ll i = 0; i < m; i++)
    {
        ll a, b, c;
        cin >> a >> b >> c;

        adj_list[a - 1].push_back(pair<ll, ll>{b - 1, c});
        rev_adj[b - 1].push_back(pair<ll, ll>{a - 1, c});
    }

    vector<ll> a1 = dijkstras(adj_list, n, 0);
    vector<ll> a2 = dijkstras(rev_adj, n, n - 1);

    ll leastCost = LLONG_MAX;
    for (ll i = 0; i < n; i++)
        for (auto x : adj_list[i])
            leastCost = min(leastCost, (ll)(a1[i] + a2[x.first] + (ll)(x.second / 2)) < 0 ? leastCost : (ll)(a1[i] + a2[x.first] + (ll)(x.second / 2)));

    cout << leastCost << endl;
}