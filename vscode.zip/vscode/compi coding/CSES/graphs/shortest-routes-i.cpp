#include <bits/stdc++.h>

typedef long long int ll;

using namespace std;

vector<ll> dijkstras(vector<vector<vector<ll>>> adj_list, ll n, ll source) // returns array containing the least weighted paths from source
{
    vector<ll> vis(n), d(n, LLONG_MAX);

    priority_queue<pair<ll, ll>, vector<pair<ll, ll>>, greater<pair<ll, ll>>> pq;

    pq.emplace(0, source); // wt, vertex
    d[source] = 0;

    while (!pq.empty())
    {
        ll u = pq.top().second; // this node is optimised from source
        pq.pop();

        if (vis[u] == 0) // need to ignore duplicate nodes
        {
            vis[u] = 1;
            for (auto x : adj_list[u])
            {
                ll v = x[0]; // need to optimise this node now
                ll wt = x[1];

                if (d[v] > d[u] + wt) // checking if this edge relaxes an already calculated distance
                {
                    d[v] = d[u] + wt;
                    pq.emplace(d[v], v); // pushing if it does
                }
            }
        }
    }

    return d;
}

int main(void)
{
    ll n, m;
    cin >> n >> m;

    vector<vector<vector<ll>>> adj_list(n);
    for (ll i = 0; i < m; i++)
    {
        ll a, b, c;
        cin >> a >> b >> c;

        a--, b--;
        adj_list[a].push_back(vector<ll>{b, c});
    }

    vector<ll> d = dijkstras(adj_list, n, 0);

    for (auto x : d)
        cout << x << ' ';
    cout << endl;
}