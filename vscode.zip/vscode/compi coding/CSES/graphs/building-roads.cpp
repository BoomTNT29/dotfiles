#include <bits/stdc++.h>

using namespace std;

int find(vector<int> &p, int i)
{
    if (p[i] == i)
        return i;

    return p[i] = find(p, p[i]);
}

int main(void)
{
    int n, m;
    cin >> n >> m;

    vector<int> p(n);
    for (int i = 0; i < n; i++)
        p[i] = i;

    for (int i = 0; i < m; i++)
    {
        int l, r;
        cin >> l >> r;

        l--, r--;
        if (find(p, l) != find(p, r))
            p[p[l]] = p[r];
    }

    vector<vector<int>> ans;

    int x;
    for (int i = 0; i < n; i++)
    {
        if (p[i] == i)
        {
            x = i;
            break;
        }
    }

    for (int i = x + 1; i < n; i++)
    {
        if (p[i] == i)
        {
            ans.push_back(vector<int>{x, i});
            x = i;
        }
    }

    cout << ans.size() << endl;
    for (auto &x : ans)
        cout << x[0] + 1 << ' ' << x[1] + 1 << endl;
}