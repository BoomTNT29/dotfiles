#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int n, m;
    cin >> n >> m;

    vector<vector<char>> grid;
    for (int i = 0; i < n; i++)
    {
        vector<char> row(m);
        for (auto &x : row)
            cin >> x;

        grid.push_back(row);
    }

    int sx, sy, ex, ey;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (grid[i][j] == 'A')
                sx = i, sy = j;
            else if (grid[i][j] == 'B')
                ex = i, ey = j;

    vector<char> visTemp(m, '0');
    vector<vector<char>> vis(n, visTemp);

    queue<pair<int, int>> pq;
    pq.emplace(sx, sy);
    vis[sx][sy] = 'a';

    vector<int> DIR = {0, -1, 0, 1, 0};

    while (!pq.empty())
    {
        int x = pq.front().first, y = pq.front().second;
        pq.pop();

        for (int i = 0; i < 4; i++)
        {
            int ni = x + DIR[i], nj = y + DIR[i + 1];

            if (ni < 0 || nj < 0 || ni == n || nj == m || grid[ni][nj] == '#' || vis[ni][nj] != '0')
                continue;

            pq.emplace(ni, nj);
            if (i == 0)
                vis[ni][nj] = 'L';
            else if (i == 1)
                vis[ni][nj] = 'U';
            else if (i == 2)
                vis[ni][nj] = 'R';
            else if (i == 3)
                vis[ni][nj] = 'D';

            if (ni == ex && nj == ey)
                pq = {};
        }
    }

    if (vis[ex][ey] == '0')
    {
        cout << "NO" << endl;
        return 0;
    }

    cout << "YES" << endl;

    int x = ex, y = ey;
    string ans;
    while (x != sx || y != sy)
    {
        ans += vis[x][y];

        if (vis[x][y] == 'L')
            x -= DIR[0], y -= DIR[1];
        else if (vis[x][y] == 'U')
            x -= DIR[1], y -= DIR[2];
        else if (vis[x][y] == 'R')
            x -= DIR[2], y -= DIR[3];
        else if (vis[x][y] == 'D')
            x -= DIR[3], y -= DIR[4];
    }

    cout << ans.size() << endl;
    for (int i = ans.size() - 1; i > -1; i--)
        cout << ans[i];
    cout << endl;
}