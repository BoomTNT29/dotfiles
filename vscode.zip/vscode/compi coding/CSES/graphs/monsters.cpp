#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int n, m;
    cin >> n >> m;

    vector<vector<char>> grid;
    for (int i = 0; i < n; i++)
    {
        vector<char> temp(m);
        for (auto &x : temp)
            cin >> x;
        grid.push_back(temp);
    }

    queue<pair<int, int>> q;

    vector<int> visTemp(m, -1), DIR = {0, -1, 0, 1, 0};
    vector<char> temp(m, '0');

    vector<vector<int>> vis(n, visTemp), monsterDis(n, visTemp);
    vector<vector<char>> p(n, temp);

    pair<int, int> source, dest = {-1, -1};
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (grid[i][j] == 'M')
                q.emplace(i, j), monsterDis[i][j] = 0;
            else if (grid[i][j] == 'A')
                source = {i, j}, vis[i][j] = 0;

    while (!q.empty())
    {
        int x = q.front().first, y = q.front().second;
        q.pop();

        for (int i = 0; i < 4; i++)
        {
            int ni = x + DIR[i], nj = y + DIR[i + 1];
            if (ni < 0 || nj < 0 || ni == n || nj == m || grid[ni][nj] != '.' || monsterDis[ni][nj] >= 0)
                continue;

            monsterDis[ni][nj] = 1 + monsterDis[x][y];
            q.emplace(ni, nj);
        }
    }

    if ((source.first != 0 && source.first != n - 1) && (source.second != 0 && source.second != m - 1))
        q.emplace(source);
    else
        dest = source;
    while (!q.empty())
    {
        int x = q.front().first, y = q.front().second;
        q.pop();

        for (int i = 0; i < 4; i++)
        {
            int ni = x + DIR[i], nj = y + DIR[i + 1];
            if (ni < 0 || nj < 0 || ni == n || nj == m || grid[ni][nj] != '.' || vis[ni][nj] >= 0)
                continue;

            vis[ni][nj] = 1 + vis[x][y];
            if (monsterDis[ni][nj] != -1 && vis[ni][nj] >= monsterDis[ni][nj])
                continue;

            q.emplace(ni, nj);

            switch (i)
            {
            case 0:
                p[ni][nj] = 'L';
                break;

            case 1:
                p[ni][nj] = 'U';
                break;

            case 2:
                p[ni][nj] = 'R';
                break;

            case 3:
                p[ni][nj] = 'D';
                break;
            }

            if (ni == 0 || nj == 0 || ni == n - 1 || nj == m - 1)
            {
                q = {};
                dest = {ni, nj};
                break;
            }
        }
    }

    if (dest != pair<int, int>{-1, -1})
    {
        stack<char> ans;
        while (dest != source)
        {
            char L = p[dest.first][dest.second];
            ans.emplace(L);

            switch (L)
            {
            case 'L':
                dest = {dest.first - DIR[0], dest.second - DIR[1]};
                break;

            case 'U':
                dest = {dest.first - DIR[1], dest.second - DIR[2]};
                break;

            case 'R':
                dest = {dest.first - DIR[2], dest.second - DIR[3]};
                break;

            case 'D':
                dest = {dest.first - DIR[3], dest.second - DIR[4]};
                break;
            }
        }

        cout << "YES" << endl
             << ans.size() << endl;
        while (!ans.empty())
        {
            cout << ans.top();
            ans.pop();
        }
        cout << endl;
    }
    else
        cout << "NO" << endl;
}