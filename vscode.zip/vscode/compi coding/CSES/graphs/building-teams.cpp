#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n);

    for (int i = 0; i < m; i++)
    {
        int l, r;
        cin >> l >> r;
        l--, r--;

        adj[l].push_back(r);
        adj[r].push_back(l);
    }

    vector<int> vis(n);
    queue<int> q;
    for (int i = 0; i < n; i++)
    {
        if (vis[i] == 0)
        {
            q.push(i);
            vis[i] = 1;
        }

        while (!q.empty())
        {
            int u = q.front();
            q.pop();

            for (auto x : adj[u])
                if (vis[x] == 0)
                {
                    vis[x] = 1 + vis[u] % 2;
                    q.push(x);
                }
                else if (vis[x] == vis[u])
                {
                    cout << "IMPOSSIBLE" << endl;
                    return 0;
                }
        }
    }

    for (auto x : vis)
        cout << x << ' ';
    cout << endl;
}