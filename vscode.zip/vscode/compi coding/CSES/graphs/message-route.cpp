#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int n, m;
    cin >> n >> m;

    int source = 0, dest = n - 1;

    vector<vector<int>> adj(n);

    for (int i = 0; i < m; i++)
    {
        int l, r;
        cin >> l >> r;

        l--, r--;
        adj[l].push_back(r);
        adj[r].push_back(l);
    }

    vector<int> vis(n, -1);
    vector<int> p(n);

    queue<int> q;
    q.push(source);
    vis[source] = 1;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();

        for (auto x : adj[u])
            if (vis[x] == -1)
            {
                vis[x] = 1 + vis[u];
                p[x] = u;
                q.push(x);
            }
    }

    if (vis[dest] == -1)
    {
        cout << "IMPOSSIBLE" << endl;
        return 0;
    }
    else
        cout << vis[dest] << endl;

    vector<int> ans(vis[dest]);
    int i = dest, it = vis[dest] - 1;
    ans[it--] = i + 1;

    while (it > -1)
    {
        i = p[i];
        ans[it--] = i + 1;
    }

    for (auto x : ans)
        cout << x << ' ';
    cout << endl;
}