#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int n, m;
    cin >> n >> m;
}