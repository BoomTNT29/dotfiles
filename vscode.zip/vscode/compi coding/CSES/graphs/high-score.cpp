#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

struct Edge
{
    ll src, dest, weight;
};

vector<ll> bellmanFord(vector<Edge> &edge_list, set<int> &path, ll v, ll e, ll src) // uses edge list repr
{
    vector<ll> dst(v, LLONG_MIN);
    dst[src] = 0;

    for (ll i = 0; i < v - 1; i++)
    {
        for (ll ed = 0; ed < e; ed++)
        {
            if (dst[edge_list[ed].src] != LLONG_MIN && dst[edge_list[ed].src] + edge_list[ed].weight > dst[edge_list[ed].dest])
                dst[edge_list[ed].dest] = dst[edge_list[ed].src] + edge_list[ed].weight;
        }
    }

    for (ll ed = 0; ed < e; ed++)
    {
        if (dst[edge_list[ed].src] != LLONG_MIN && dst[edge_list[ed].src] + edge_list[ed].weight > dst[edge_list[ed].dest])
        {
            dst[edge_list[ed].dest] = dst[edge_list[ed].src] + edge_list[ed].weight;
            if (path.find(edge_list[ed].dest) != path.end())
            {
                vector<ll> v = {-1};
                return v;
            }
        }
    }

    return dst;
}

int main(void)
{
    int n, m;
    cin >> n >> m;

    vector<Edge> edge_list;

    vector<int> vis(n, 0);
    vector<vector<int>> adj_list(n), rev_adj(n);
    for (int i = 0; i < m; i++)
    {
        ll a, b, c;
        cin >> a >> b >> c;
        edge_list.push_back(Edge{a - 1, b - 1, c});
        adj_list[a - 1].push_back(b - 1);
        rev_adj[b - 1].push_back(a - 1);
    }

    queue<int> q;
    q.emplace(0);
    vis[0] = 1;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();

        for (auto x : adj_list[u])
            if (vis[x] == 0)
                q.emplace(x), vis[x] = 1;
    }

    q.emplace(n - 1);
    vis[n - 1] = 1;
    set<int> path;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();

        for (auto x : rev_adj[u])
            if (vis[x] < 2)
            {
                if (vis[x] == 1)
                    path.insert(x);
                q.emplace(x), vis[x] = 2;
            }
    }

    vector<ll> ans = bellmanFord(edge_list, path, n, m, 0);

    cout << ans[ans.size() - 1] << endl;
}