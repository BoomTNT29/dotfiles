#include <bits/stdc++.h>

using namespace std;

vector<int> DIR = {0, -1, 0, 1, 0};

void dfs(vector<vector<char>> &grid, vector<vector<int>> &vis, int count, int x, int y)
{
    vis[x][y] = 1;

    for (int i = 0; i < 4; i++)
    {
        int ni = x + DIR[i], nj = y + DIR[i + 1];

        if (ni < 0 || nj < 0 || ni == grid.size() || nj == grid[0].size() || vis[ni][nj] || grid[ni][nj] == '#')
            continue;

        dfs(grid, vis, count, ni, nj);
    }
}

int main(void)
{
    int n, m;

    cin >> n >> m;

    vector<vector<char>> grid;

    for (int i = 0; i < n; i++)
    {
        vector<char> row(m);
        for (auto &x : row)
            cin >> x;

        grid.push_back(row);
    }

    queue<pair<int, int>> pq;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (grid[i][j] == '.')
                pq.emplace(make_pair(i, j));

    vector<int> visTemp(m);
    vector<vector<int>> vis(n, visTemp);

    int count = 0;
    while (!pq.empty())
    {
        int x = pq.front().first, y = pq.front().second;
        pq.pop();

        if (vis[x][y] == 1)
            continue;

        dfs(grid, vis, count++, x, y);
    }

    cout << count << endl;
}