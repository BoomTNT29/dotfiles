#include <bits/stdc++.h>

using namespace std;

void dfs(vector<vector<int>> &adj, vector<int> &v, vector<int> &p, int x, int parent, int &source, int &dest, bool &flag)
{
    v[x] = 1 + v[parent];

    for (auto y : adj[x])
        if (!flag)
            return;
        else if (v[y] == 0)
        {
            p[y] = x;
            dfs(adj, v, p, y, x, source, dest, flag);
        }
        else if (v[y] - v[x] > 1)
        {
            flag = false;
            source = y;
            dest = x;
            cout << v[y] - v[x] + 2 << endl;
            return;
        }
}

int main(void)
{
    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n);

    for (int i = 0; i < m; i++)
    {
        int l, r;
        cin >> l >> r;
        l--, r--;

        adj[l].push_back(r);
        adj[r].push_back(l);
    }

    vector<int> vis(n), p(n, -1);

    bool flag = true;
    int source, dest;

    for (int i = 0; (i < n) && flag; i++)
        if (vis[i] == 0)
            dfs(adj, vis, p, i, -1, source, dest, flag);

    if (flag)
        cout << "IMPOSSIBLE" << endl;
    else
    {
        int i = source;
        cout << dest + 1 << ' ';
        while (i != dest)
        {
            cout << i + 1 << ' ';
            i = p[i];
        }
        cout << dest + 1 << ' ';
    }
}