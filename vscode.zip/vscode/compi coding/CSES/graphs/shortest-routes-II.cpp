#include <bits/stdc++.h>

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

using namespace std;

typedef long long int ll;

struct Edge
{
    int src, dest, weight;
};

vector<int> bellmanFord(vector<Edge> &edge_list, int v, int e, int src) // uses edge list repr
{
    vector<int> dst(v, INT_MAX);
    dst[src] = 0;

    for (int i = 0; i < v - 1; i++)
    {
        for (int ed = 0; ed < e; ed++)
        {
            if (dst[edge_list[ed].src] != INT_MAX && dst[edge_list[ed].src] + edge_list[ed].weight < dst[edge_list[ed].dest])
                dst[edge_list[ed].dest] = dst[edge_list[ed].src] + edge_list[ed].weight;
        }
    }

    for (int ed = 0; ed < e; ed++)
    {
        if (dst[edge_list[ed].src] != INT_MAX && dst[edge_list[ed].src] + edge_list[ed].weight < dst[edge_list[ed].dest])
        {
            vector<int> v = {-1};
            return v;
        }
    }

    return dst;
}

vector<vector<ll>> floyd_warshalls(vector<vector<ll>> &matrix, int v) // uses adjacency representation
{
    vector<vector<ll>> d(matrix.begin(), matrix.end());

    for (int k = 0; k < v; k++)
        for (int i = 0; i < v; i++)
            for (int j = 0; j < v; j++)
                if (d[i][k] != LLONG_MAX && d[k][j] != LLONG_MAX && d[i][j] > d[i][k] + d[k][j])
                    d[i][j] = d[i][k] + d[k][j];

    return d;
}

int main(void)
{
    fast_io;

    int n, m, q;
    cin >> n >> m >> q;

    // there are three ways to represent a graph;
    vector<ll> temp(n, LLONG_MAX);
    vector<vector<ll>> adj_matrix(n, temp);
    vector<vector<int>> adj_list(n);
    vector<Edge> edge_list;

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            if (i == j)
                adj_matrix[i][i] = (ll)0;

    ll l, r, wt;
    for (int i = 0; i < m; i++)
    {
        cin >> l >> r >> wt;
        l--, r--;
        adj_matrix[l][r] = min(wt, adj_matrix[l][r]);
        adj_matrix[r][l] = min(wt, adj_matrix[r][l]);
    }

    vector<vector<ll>> ans = floyd_warshalls(adj_matrix, n);

    while (q--)
    {
        cin >> l >> r;
        l--, r--;
        cout << (ans[l][r] == LLONG_MAX ? -1 : ans[l][r]) << endl;
    }
}