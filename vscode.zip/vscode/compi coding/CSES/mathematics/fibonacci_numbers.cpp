#include <bits/stdc++.h>

using namespace std;

int m = 1E9 + 7;

vector<vector<long long int>> mm(vector<vector<long long int>> arr1, vector<vector<long long int>> arr2)
{
    vector<vector<long long int>> ret = {
        {(arr1[0][0] * arr2[0][0] + arr1[0][1] * arr2[1][0]) % m,
         (arr1[0][0] * arr2[0][1] + arr1[0][1] * arr2[1][1]) % m},
        {(arr1[1][0] * arr2[0][0] + arr1[1][1] * arr2[1][0]) % m,
         (arr1[1][0] * arr2[0][1] + arr1[1][1] * arr2[1][1]) % m}};

    return ret;
}

vector<vector<long long int>> pow(vector<vector<long long int>> arr, long long int m)
{
    if (m == 1)
        return arr;

    if (m % 2 == 0)
        return pow(mm(arr, arr), m / 2);
    else
        return mm(pow(mm(arr, arr), m / 2), arr);
}

long long int fib(long long int n)
{
    if (n < 2)
        return n;

    vector<vector<long long int>> A = {{1, 1}, {1, 0}};

    A = pow(A, n);

    return A[1][0];
}

int main(void)
{
    long long int n;
    cin >> n;
    cout << fib(n);
}