#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

vi reserved;
ll paths = 0;
int visited[7][7];

bool check(int row, int column)
{
    return (row < 0 || row > 6 || column < 0 || column > 6 || visited[row][column]) ||

           ((column >= 1 && column <= 5 && !visited[row][column + 1] && !visited[row][column - 1]) &&
			((row == 0 && visited[row + 1][column]) || (row == 6 && visited[row - 1][column]))) 
		||
			((row >= 1 && row <= 5 && !visited[row + 1][column] && !visited[row - 1][column]) &&
				((column == 0 && visited[row][column + 1]) || (column == 6 && visited[row][column - 1]))) 
		
		|| (row >= 1 && row <= 5 && column >= 1 && column <= 5 && visited[row + 1][column] 
			&& visited[row - 1][column] && !visited[row][column + 1] && !visited[row][column - 1])
 
		|| (row >= 1 && row <= 5 && column >= 1 && column <= 5 && visited[row][column + 1] && visited[row][column - 1] 
			&& !visited[row + 1][column] && !visited[row - 1][column]);
}

void recur(int steps, int row, int column, char c)
{
    if (check(row, column) || (steps >= 0 && (reserved[steps] != -1 && c != reserved[steps])))
        return;

    if (row == 6 && column == 0)
    {
        if (steps == 48)
            paths++;

        return;
    }

    visited[row][column] = true;
    recur(steps + 1, row + 1, column, 'R');
    recur(steps + 1, row - 1, column, 'L');
    recur(steps + 1, row, column + 1, 'D');
    recur(steps + 1, row, column - 1, 'U');
    visited[row][column] = false;
}

void solve(void)
{
    string s;
    cin >> s;

    fr(i, 48)
    {
        switch (s[i])
        {
        case '?':
            reserved.push_back(-1);
            break;
        case 'R':
            reserved.push_back('R');
            break;
        case 'U':
            reserved.push_back('U');
            break;
        case 'L':
            reserved.push_back('L');
            break;
        case 'D':
            reserved.push_back('D');
            break;
        }
    }

    recur(-1, 0, 0, '?');
    cout << paths << endl;
}

int main(void)
{
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}