#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll n, sum = 0, x;
    cin >> n;

    for (int i = 0; i < n - 1; i++)
    {
        cin >> x;
        sum += x;
    }

    cout << ((n * (n + 1)) / (ll)2) - sum << endl;
}