#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        ll x, y, ans = 0, eOo = 0;
        cin >> y >> x;

        ll above = 0;
        if (x > y)
            above = 1, eOo = x % 2;
        else if (x < y)
            above = 0, eOo = y % 2;
        else
        {
            cout << (ll)1 + x * (x - (ll)1) << endl;
            continue;
        }

        if (above)
            ans = (ll)1 + x * (x - (ll)1);
        else
            ans = (ll)1 + y * (y - (ll)1);

        ans += (x - y) * (eOo ? 1 : -1);

        cout << ans << endl;
    }
}