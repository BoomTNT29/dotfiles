#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int n;
    cin >> n;

    if (n == 1)
        cout << 1 << endl;
    else if (n < 4)
        cout << "NO SOLUTION" << endl;
    else
    {
        int biggestOdd = n % 2 ? n : n - 1, biggestEven = n % 2 ? n - 1 : n;

        while (biggestOdd > 0)
        {
            cout << biggestOdd << ' ';
            biggestOdd -= 2;
        }

        while (biggestEven > 0)
        {
            cout << biggestEven << ' ';
            biggestEven -= 2;
        }

        cout << endl;
    }
}