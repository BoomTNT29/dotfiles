#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

vector<bool> rows(8, true), leftDiagnols(15, true), rightDiagnols(15, true);
vector<vector<char>> board(8);
ll ans = 0;

void rec(int column)
{
    if (column == 8)
    {
        ans++;
        return;
    }

    fr(i, 8)
    {
        if (board[i][column] == '.' && rows[i] == true && leftDiagnols[i + column] == true && rightDiagnols[i - column + 7] == true)
        {
            rows[i] = false;
            leftDiagnols[i + column] = false;
            rightDiagnols[i - column + 7] = false;
            rec(column + 1);
            rows[i] = true;
            leftDiagnols[i + column] = true;
            rightDiagnols[i - column + 7] = true;
        }
    }
}

void solve(void)
{
    for (auto &x : board)
    {
        fr(i, 8)
        {
            char c;
            cin >> c;
            x.push_back(c);
        }
    }

    rec(0);
    cout << ans << endl;
}

int main(void)
{
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}