#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    string n;
    cin >> n;

    vi letters(26, 0);

    fr(i, n.size())
        letters[n[i] - 'A'] += 1;

    bool flag = false;
    fr(i, 26)
    {
        if (letters[i] % 2)
        {
            if (flag)
            {
                cout << "NO SOLUTION" << endl;
                return;
            }
            flag = true;
        }
    }

    vector<char> ans(n.size());
    ll pointer = 0;
    fr(i, 26)
    {
        while (letters[i] > 0)
        {
            if (letters[i] == 1)
            {
                ans[(n.size() - 1) / 2] = 'A' + i;
                letters[i] = 0;
            }
            else
            {
                ans[pointer] = 'A' + i;
                ans[n.size() - pointer - 1] = 'A' + i;
                pointer++;
                letters[i] -= 2;
            }
        }
    }

    for (auto x : ans)
        cout << x;
    nl;
}

int main(void)
{
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}