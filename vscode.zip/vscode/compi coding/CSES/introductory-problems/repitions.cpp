#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    string s;
    cin >> s;

    int count, longest = 0;

    for (int i = 0; i < (int)s.size(); i++)
    {
        if (i == 0 || s[i] != s[i - 1])
        {
            if (count >= longest)
                longest = count + 1;
            count = 0;
        }
        else
            count++;
    }

    if (count >= longest)
        longest = count + 1;

    cout << longest << endl;
}