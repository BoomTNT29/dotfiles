#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    ll n = 1;
    cin >> n;

    ll digits = log10(n) + 1;

    ll trailingZeros = 0, temp = n;

    temp = 5;
    while (n / temp > 0)
    {
        trailingZeros += n / temp;
        temp *= 5;
    }

    cout << trailingZeros << endl;
}

int main(void)
{
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}