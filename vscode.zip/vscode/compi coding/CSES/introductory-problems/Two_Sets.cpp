#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    ll n = 1, swaps = 0;
    cin >> n;

    ll sum1 = (n * (n + 1)) / 2;
    vll ans1(n), ans2(n, -1);

    if (sum1 % 2)
    {
        cout << "NO" << endl;
        return;
    }
    else
    {
        rep(i, 1, n)
            ans1[i - 1] = i;

        ll totalSumForEach = sum1 / 2;
        ll pointer = n;
        while (totalSumForEach > 0)
        {
            if (pointer <= totalSumForEach)
            {
                swap(ans1[pointer - 1], ans2[pointer - 1]);
                totalSumForEach -= pointer;
                swaps++;
            }
            pointer--;
        }
    }

    cout << "YES" << endl;
    cout << n - swaps << endl;
    fr(i, n)
    {
        if (ans1[i] != -1)
            cout << ans1[i] << ' ';
    }
    nl;
    cout << swaps << endl;
    fr(i, n)
    {
        if (ans2[i] != -1)
            cout << ans2[i] << ' ';
    }
    nl;
}

int main(void)
{
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}