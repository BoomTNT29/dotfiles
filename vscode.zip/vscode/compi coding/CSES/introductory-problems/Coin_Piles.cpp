#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    ll a, b;
    cin >> a >> b;

    ll u = (2 * b - a), v = 2 * a - b;
    if (u >= 0 && u % 3 == 0 && v >= 0 && v % 3 == 0)
        cout << "YES" << endl;
    else
        cout << "NO" << endl;
}

int main(void)
{
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}