#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void flip(string &s, ll *number, int index)
{
    int n = s.size();
    if (s[index] == '0')
    {
        *number += (ll)exp2(n - index - 1);
        s[index] = '1';
    }
    else
    {
        *number -= (ll)exp2(n - index - 1);
        s[index] = '0';
    }
}

void solve(void)
{
    int n = 1;
    cin >> n;

    string s;
    ll number = 0;
    fr(i, n)
        s += '0';

    set<ll> finNumbers;
    ll total = exp2(n) - 1;
    cout << s << endl;

    while (total)
    {
        finNumbers.insert(number);
        rep(i, 1, n)
        {
            flip(s, &number, n - i);
            if (finNumbers.find(number) != finNumbers.end())
            {
                flip(s, &number, n - i);
            }
            else
            {
                cout << s << endl;
                break;
            }
        }
        total--;
    }
}

int main(void)
{
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}