#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll n;
    cin >> n;

    while (n != 1)
    {
        cout << n << ' ';
        n = n % 2 ? (n * (ll)3 + (ll)1) : (n / (ll)2);
    }

    cout << n << endl;
}