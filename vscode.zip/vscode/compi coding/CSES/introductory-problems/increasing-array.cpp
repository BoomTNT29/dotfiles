#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int n;
    cin >> n;

    ll biggest = 0, moves = 0, temp = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> temp;

        if (i == 0 || biggest < temp)
            biggest = temp;
        else
            moves += biggest - temp;
    }

    cout << moves << endl;
}