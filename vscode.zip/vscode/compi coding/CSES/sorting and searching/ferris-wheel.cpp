#include <bits/stdc++.h>
#define sort(x) sort(x.begin(), x.end())

using namespace std;

typedef long long int ll;

int main(void)
{
    int n;
    ll x;
    cin >> n >> x;

    vector<ll> wts(n);
    for (auto &x : wts)
        cin >> x;

    sort(wts);

    int ans = 0, wtPointerFront = 0, wtPointerBack = (ll)wts.size() - 1;

    while (wtPointerFront <= wtPointerBack)
    {
        if (wts[wtPointerFront] + wts[wtPointerBack] <= x)
            wtPointerFront++, wtPointerBack--;
        else
            wtPointerBack--;

        ans++;
    }

    cout << ans << endl;
}