#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

void merge(vector<pair<ll, ll>> &arr, ll low, ll high)
{
    vector<pair<ll, ll>> b;
    ll lp = low, i = 0, mid = (high - low) / 2 + low, rp = mid + 1;

    while (lp <= mid && rp <= high)
    {
        if (arr[lp].first < arr[rp].first)
            b.push_back(arr[lp++]);
        else
            b.push_back(arr[rp++]);
    }

    while (lp <= mid)
        b.push_back(arr[lp++]);
    while (rp <= high)
        b.push_back(arr[rp++]);

    i = 0, lp = low;
    while (lp <= high)
        arr[lp++] = b[i++];
}

void mergeSort(vector<pair<ll, ll>> &arr, ll low, ll high)
{
    ll mid = (high - low) / 2 + low;
    if (high <= low)
        return;

    mergeSort(arr, mid + 1, high);
    mergeSort(arr, low, mid);
    merge(arr, low, high);
}

int main(void)
{
    vector<pair<ll, ll>> arr;
    pair<ll, ll> pr;

    ll n, temp;
    cin >> n;
    n = 2 * n - 1;

    for (ll i = 0; i <= n; i++)
    {
        cin >> temp;
        pr.first = temp;
        if (i % 2 == 0)
            pr.second = 1;
        else
            pr.second = -1;
        arr.push_back(pr);
    }

    mergeSort(arr, 0, n);

    ll max = 0, sum = 0;

    n++;
    ll i = 0;
    while (i < n)
    {
        if (sum > max)
            max = sum;

        sum += arr[i++].second;
    }

    cout << max << endl;
}