#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int n;
    ll x;
    cin >> n >> x;

    vector<pair<ll, int>> vals(n);
    int counter = 1;
    for (auto &x : vals)
        cin >> x.first, x.second = counter++;

    sort(vals.begin(), vals.end());

    int forwardPointer = 0, backwardPointer = n - 1;
    while (forwardPointer < backwardPointer)
    {
        if (vals[forwardPointer].first + vals[backwardPointer].first == x)
        {
            cout << vals[backwardPointer].second << ' ' << vals[forwardPointer].second << endl;
            break;
        }

        else if (vals[forwardPointer].first + vals[backwardPointer].first < x)
            forwardPointer++;

        else
            backwardPointer--;
    }

    if (forwardPointer >= backwardPointer)
        cout << "IMPOSSIBLE" << endl;
}