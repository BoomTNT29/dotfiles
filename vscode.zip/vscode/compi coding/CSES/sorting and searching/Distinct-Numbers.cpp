#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int n;
    cin >> n;

    ll temp;
    set<ll> store;

    while (n--)
    {
        cin >> temp;
        store.insert(temp);
    }

    cout << store.size() << endl;
}