#include <bits/stdc++.h>
#define sort(x) sort(x.begin(), x.end());

using namespace std;

typedef long long int ll;

int main(void)
{
    int n, m;
    ll k;
    cin >> n >> m >> k;

    vector<ll> req(n), avail(m);

    for (auto &x : req)
        cin >> x;

    for (auto &x : avail)
        cin >> x;
    
    sort(req);
    sort(avail);

    int reqPointer = 0, availPointer = 0, ans = 0;

    while (reqPointer < req.size() && availPointer < avail.size())
    {
        if (abs(req[reqPointer] - avail[availPointer]) <= k)
        {
            ans++;
            reqPointer++;
            availPointer++;
        }

        else if (req[reqPointer] < avail[availPointer])
            reqPointer++;
        
        else
            availPointer++;
    }

    cout << ans << endl;
}