#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int n, m;
    cin >> n >> m;

    multiset<ll> prices;
    ll temp;
    for (int i = 0; i < n; i++)
    {
        cin >> temp;
        prices.insert(-temp);
    }

    vector<ll> ans;

    for (int i = 0; i < m; i++)
    {
        cin >> temp;

        if (prices.lower_bound(-temp) != prices.end())
        {
            ans.push_back(-(*prices.lower_bound(-temp)));
            prices.erase(prices.lower_bound(-temp));
        }
        else
            ans.push_back(-1);
    }

    for (auto x : ans)
        cout << x << endl;
}