#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

ll mergeSort(vector<ll> &v, int n, int l, int r)
{
    int m = (l + r) / 2;
    ll diffMax = v[r] - v[l];
    vector<ll> b;

    ll lp = l, rp = m + 1;

    while (lp <= m && rp <= r)
        if (v[lp] < v[rp])
            b.push_back(v[lp++]);
        else
            b.push_back(v[rp++]);

    while (lp <= m)
        b.push_back(v[lp++]);

    while (rp <= r)
        b.push_back(v[rp++]);

    for (lp = l, rp = 0; lp <= r; lp++, rp++)
        v[lp] = b[rp];

    return diffMax;
}

ll merge(vector<ll> &v, int n, int l, int r)
{
    if (l < r)
    {
        int m = (l + r) / 2;

        ll t = max(merge(v, n, l, m), merge(v, n, m + 1, r));
        return max(t, mergeSort(v, n, l, r));
    }
    return LLONG_MIN;
}

int main(void)
{
    int n;
    cin >> n;

    vector<ll> prefSum = {0};
    ll temp, pref = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> temp;
        pref += temp;
        prefSum.push_back(pref);
    }

    ll ans = merge(prefSum, n + 1, 0, n);

    cout << ans << endl;
}