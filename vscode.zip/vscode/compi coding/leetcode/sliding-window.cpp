#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    vector<int> maxSlidingWindow(vector<int> &nums, int k)
    {
        deque<int> keys;
        vector<int> answer;

        int i;
        for (i = 0; i < k; i++)
        {
            while (keys.size() && nums[keys.back()] < nums[i])
                keys.pop_back();
            keys.push_back(i);
        }
        answer.push_back(nums[keys[0]]);

        while (i < nums.size())
        {
            if (keys.size() && nums[keys[0]] == nums[i - k])
                keys.pop_front();
            while (keys.size() && nums[keys.back()] < nums[i])
                keys.pop_back();
            keys.push_back(i);
            answer.push_back(nums[keys[0]]);
            i++;
        }

        return answer;
    }
};