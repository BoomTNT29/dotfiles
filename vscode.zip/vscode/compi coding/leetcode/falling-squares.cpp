#include <bits/stdc++.h>

using namespace std;

struct item
{
    int height;
};

struct segTree
{
    int size;
    vector<item> values;
    vector<item> lazy;

    void init(int n)
    {
        size = 1;
        while (size < n)
            size *= 2;
        values.resize(size * 2);
        lazy.resize(size * 2);
    }

    void set(int x, int l, int r, int lx, int rx, int i)
    {
        if (lazy[i].height != 0)
        {
            values[i].height = lazy[i].height;
            if (rx - lx > 1)
            {
                lazy[2 * i + 1].height = lazy[i].height;
                lazy[2 * i + 2].height = lazy[i].height;
            }
            lazy[i].height = 0;
        }

        if (lx >= r || rx <= l)
            return;

        if (lx >= l && rx <= r)
        {
            values[i].height = x;
            if (rx - lx > 1)
            {
                lazy[2 * i + 1].height = x;
                lazy[2 * i + 2].height = x;
            }
            return;
        }

        int m = (lx + rx) / 2;
        set(x, l, r, lx, m, 2 * i + 1);
        set(x, l, r, m, rx, 2 * i + 2);
        values[i].height = max(values[2 * i + 1].height, values[2 * i + 2].height);
    }

    void set(int l, int r, int x)
    {
        set(x, l, r, 0, size - 1, 0);
    }

    int rangeMaxHeight(int l, int r, int i, int lx, int rx)
    {
        if (lazy[i].height != 0)
        {
            values[i].height = lazy[i].height;
            if (rx - lx > 1)
            {
                lazy[2 * i + 1].height = lazy[i].height;
                lazy[2 * i + 2].height = lazy[i].height;
            }
            lazy[i].height = 0;
        }

        if (lx >= r || rx <= l)
            return INT_MIN;

        if (lx >= l && rx <= r)
            return values[i].height;

        int m = (lx + rx) / 2;
        int left = rangeMaxHeight(l, r, 2 * i + 1, lx, m);
        int right = rangeMaxHeight(l, r, 2 * i + 2, m, rx);
        return max(left, right);
    }

    int rangeMaxHeight(int l, int r)
    {
        return rangeMaxHeight(l, r, 0, 0, size - 1);
    }
};

class Solution
{
public:
    vector<int> fallingSquares(vector<vector<int>> &positions)
    {
        vector<int> coords, ans;
        for (auto &x : positions)
        {
            coords.push_back(x[0]);
            coords.push_back(x[0] + x[1]);
        }

        sort(coords.begin(), coords.end());

        segTree st;
        st.init(coords.size() - 1);

        for (auto &x : positions)
        {
            int l = lower_bound(coords.begin(), coords.end(), x[0]) - coords.begin();
            int r = lower_bound(coords.begin(), coords.end(), x[0] + x[1]) - coords.begin();
            int h = st.rangeMaxHeight(l, r);
            st.set(l, r, h + x[1]);
            if (ans.empty())
                ans.push_back(h + x[1]);
            else
                ans.push_back(max(ans.back(), h + x[1]));
        }

        return ans;
    }
};

int main(void)
{
    vector<vector<int>> positions = {{1, 2}, {2, 3}, {6, 1}};
    Solution y;

    for (auto x : y.fallingSquares(positions))
        cout << x << ' ';
    cout << endl;
}