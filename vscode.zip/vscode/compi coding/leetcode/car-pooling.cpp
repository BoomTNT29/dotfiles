#include <bits/stdc++.h>

using namespace std;

bool carPooling(vector<vector<int>> &trips, int capacity)
{
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> heap;

    for (int i = 0; i < trips.size(); ++i)
    {
        heap.push({trips[i][1], trips[i][0]});
        heap.push({trips[i][2], -trips[i][0]});
    }
    int onboard = 0;
    while (!heap.empty())
    {
        onboard = onboard + heap.top().second;
        heap.pop();
        if (onboard > capacity)
            return false;
    }
    return true;
}

int main(void)
{
    vector<vector<int>> trips = {{2, 1, 5}, {3, 3, 7}};
    int capacity = 4;

    cout << carPooling(trips, capacity) << endl;
}