struct bst
{
    int val, nodes, perms;
    struct bst *left = NULL, *right = NULL;
    bst() : val(0), left(NULL), right(NULL), nodes(1), perms(1) {}
    bst(int x) : val(x), left(NULL), right(NULL), nodes(1), perms(1) {}
    bst(int x, struct bst *left, struct bst *right) : val(x), left(left), right(right), nodes(0), perms(1) {}
};

class Solution
{
public:
    void insert(struct bst *root, int val)
    {
        root->nodes += 1;

        if (root->val < val)
        {
            if (root->left == NULL)
            {
                struct bst *n = new bst(val);
                root->left = n;
                return;
            }
            else
            {
                insert(root->left, val);
                return;
            }
        }

        if (root->val > val)
        {
            if (root->right == NULL)
            {
                struct bst *n = new bst(val);
                root->right = n;
                return;
            }
            else
            {
                insert(root->right, val);
                return;
            }
        }
    }

    int MODULO = 1E9 + 7;

    int fac(int n)
    {
        if (n < 3)
            return n;

        return (n * fac(n - 1)) % (MODULO);
    }

    void recur(struct bst *root)
    {
        cout << root->val << ' ' << root->nodes << endl;

        if (root->nodes < 3)
        {
            if (root->left == NULL || root->right == NULL)
                root->perms = 1;
            else
                root->perms = 2;

            return;
        }

        if (root->left == NULL)
        {
            root->perms = root->right->perms;
            return;
        }

        if (root->right == NULL)
        {
            root->perms = root->left->perms;
            return;
        }

        recur(root->right);
        recur(root->left);

        root->perms = ((fac(root->nodes - 1) * ((root->right->perms) * (root->left->perms)) % MODULO) % MODULO) / ((fac(root->right->nodes) * fac(root->left->nodes)) % MODULO);
        return;
    }

    int numOfWays(vector<int> &nums)
    {
        struct bst *root = new bst(nums[0]);

        for (int i = 1; i < nums.size(); i++)
        {
            insert(root, nums[i]);
        }

        recur(root);
        return root->perms - 1;
    }
};