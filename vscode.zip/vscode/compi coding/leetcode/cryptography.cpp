#include <bits/stdc++.h>

using namespace std;

struct item
{
    long long int a11, a12, a21, a22;
};

struct segTree
{
    int size;
    long long mod;
    vector<item> values;

    void init(int n, long long r)
    {
        size = 1;
        while (size < n)
            size *= 2;
        mod = r;
        values.resize(size * 2);
    }

    void mm(item &a, item &b, item &c)
    {
        c.a11 = ((a.a11 * b.a11) + (a.a12 * b.a21)) % mod;
        c.a12 = ((a.a11 * b.a12) + (a.a12 * b.a22)) % mod;
        c.a21 = ((a.a21 * b.a11) + (a.a22 * b.a21)) % mod;
        c.a22 = ((a.a21 * b.a12) + (a.a22 * b.a22)) % mod;
    }

    item mm(item a, item b)
    {
        return {
            ((a.a11 * b.a11) + (a.a12 * b.a21)) % mod,
            ((a.a11 * b.a12) + (a.a12 * b.a22)) % mod,
            ((a.a21 * b.a11) + (a.a22 * b.a21)) % mod,
            ((a.a21 * b.a12) + (a.a22 * b.a22)) % mod};
    }

    void build(vector<item> &v)
    {
        for (int i = 0; i < v.size(); i++)
        {
            values[size - 1 + i] = v[i];
        }

        for (int i = size - 2; i > -1; i--)
        {
            mm(values[2 * i + 1], values[2 * i + 2], values[i]);
        }
    }

    item rangeQuery(int l, int r, int ss, int se, int o)
    {
        if (l > se || r < ss)
            return {1, 0, 0, 1};

        if (ss >= l && se <= r)
            return values[o];

        int m = (ss + se) / 2;
        return mm(rangeQuery(l, r, ss, m, 2 * o + 1), rangeQuery(l, r, m + 1, se, 2 * o + 2));
    }

    item rangeQuery(int l, int r)
    {
        return rangeQuery(l, r, 0, size - 1, 0);
    }
};

int main(void)
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;
    long long r;
    cin >> r >> n >> m;
    segTree st;
    st.init(n, r);

    vector<item> v(n);

    for (auto &x : v)
        cin >> x.a11 >> x.a12 >> x.a21 >> x.a22;

    st.build(v);

    int l;
    int r1;
    item ans;
    for (int i = 0; i < m; i++)
    {
        cin >> l >> r1;
        l--, r1--;
        ans = st.rangeQuery(l, r1);
        cout << ans.a11 << ' ' << ans.a12 << endl;
        cout << ans.a21 << ' ' << ans.a22 << endl
             << endl;
    }
}