#include <bits/stdc++.h>

using namespace std;

class NumArray
{
public:
    int size;
    vector<int> tree;

    NumArray(vector<int> &nums)
    {
        size = 1;
        while (size < nums.size())
            size *= 2;

        tree.resize(size * 2);

        for (int i = 0; i < nums.size(); i++)
        {
            tree[size - 1 + i] = nums[i];
        }

        for (int i = size - 2; i > -1; i--)
        {
            tree[i] = tree[2 * i + 1] + tree[2 * i + 2];
        }
    }

    void update(int index, int val)
    {
        index = size - 1 + index;
        tree[index] = val;
        index = floor((index - 1) / 2.0);

        while (index > -1)
        {
            tree[index] = tree[index * 2 + 1] + tree[index * 2 + 2];
            index = floor((index - 1) / 2.0);
        }
    }

    int rangeQuery(int l, int r, int ss, int se, int o)
    {
        if (l > se || r < ss)
            return 0;

        if (l <= ss && r >= se)
            return tree[o];

        int m = (ss + se) / 2;
        int m1 = rangeQuery(l, r, ss, m, 2 * o + 1);
        int m2 = rangeQuery(l, r, m + 1, se, 2 * o + 2);

        return m1 + m2;
    }

    int sumRange(int left, int right)
    {
        return rangeQuery(left, right, 0, size - 1, 0);
    }
};

/**
 * Your NumArray object will be instantiated and called as such:
 * NumArray* obj = new NumArray(nums);
 * obj->update(index,val);
 * int param_2 = obj->sumRange(left,right);
 */
