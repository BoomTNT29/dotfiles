#include <bits/stdc++.h>

using namespace std;

int height(unordered_map<int, pair<int, int>> &mp, vector<int> &vis, int u)
{
    if (mp.find(u) == mp.end())
        return 0;

    if (vis[mp[u].second] != -1)
        return vis[mp[u].second];

    return vis[mp[u].second] = 1 + height(mp, vis, mp[u].first);
}

class Solution
{
public:
    int longestConsecutive(vector<int> &nums)
    {
        unordered_map<int, pair<int, int>> mp;
        vector<int> vis(nums.size(), -1);

        for (int i = 0; i < nums.size(); i++)
            mp[nums[i]] = make_pair(nums[i] - 1, i);

        int maxi = 0, c;
        bool flag = true;
        for (auto x : mp)
        {
            if (vis[x.second.second] != -1)
                continue;

            c = height(mp, vis, x.first);
            maxi = max(maxi, c);
        }

        return maxi;
    }
};

int main(void)
{
    vector<int> nums = {100, 4, 200, 1, 3, 2, 9, 6, 5, 7, 8, 0, -1, -2};
    Solution s;
    cout << s.longestConsecutive(nums) << endl;
}