#include <bits/stdc++.h>

#define fast_io                  \
    ios::sync_with_stdio(false); \
    cin.tie(0);                  \
    cout.tie(0);

using namespace std;

class Solution
{
public:
    vector<int> DIR = {0, 1, 0, -1, 0};
    vector<vector<int>> updateMatrix(vector<vector<int>> &mat)
    {
        fast_io;

        int m = mat.size(), n = mat[0].size();
        queue<pair<int, int>> q;

        for (int i = 0; i < m; i++)
            for (int j = 0; j < n; j++)
            {
                if (mat[i][j] == 0)
                    q.emplace(i, j);
                else
                    mat[i][j] = -1; // not visited yet!
            }

        while (!q.empty())
        {
            auto [x, y] = q.front();
            q.pop();

            for (int i = 0; i < 4; i++)
            {
                int ni = x + DIR[i], nj = y + DIR[i + 1];

                if (ni < 0 || ni == m || nj < 0 || nj == n || mat[ni][nj] != -1)
                    continue;

                mat[ni][nj] = mat[x][y] + 1;
                q.emplace(ni, nj);
            }
        }

        return mat;
    }
};

int main(void)
{
    Solution s;

    vector<vector<int>> mat = {{0}, {0}, {0}, {0}, {0}};

    vector<vector<int>> ans = s.updateMatrix(mat);

    for (auto &x : ans)
    {
        for (auto y : x)
            cout << y << ' ';
        cout << endl;
    }
}