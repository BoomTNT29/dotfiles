#include <bits/stdc++.h>

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

using namespace std;

class Solution
{
public:
    int reachableNodes(int n, vector<vector<int>> &edges, vector<int> &restricted)
    {
        fast_io;

        vector<vector<int>> adj_list(n);
        vector<int> r(n, 0);

        for (auto x : restricted)
            r[x] = 1;

        for (auto &x : edges)
        {
            adj_list[x[0]].push_back(x[1]);
            adj_list[x[1]].push_back(x[0]);
        }

        queue<int> q;
        q.push(0);
        int s = 0;
        vector<int> v(n, 0);
        v[s] = 1;

        while (q.empty() == 0)
        {
            s = q.front();
            q.pop();
            for (auto x : adj_list[s])
            {
                if (v[x] == 0 && r[x] != 1)
                {
                    v[x] = 1;
                    q.push(x);
                }
            }
        }

        int count = 0;
        for (int i = 0; i < n; i++)
            count += v[i];

        return count;
    }
};

int main(void)
{
    Solution s;

    int n = 7;
    vector<vector<int>> edges = {{0, 1}, {0, 2}, {0, 5}, {0, 4}, {3, 2}, {6, 5}};
    vector<int> r = {4, 2, 1};

    cout << s.reachableNodes(n, edges, r) << endl;
}