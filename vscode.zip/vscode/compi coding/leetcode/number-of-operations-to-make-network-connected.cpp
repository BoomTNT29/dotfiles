#include <bits/stdc++.h>

using namespace std;

int find(vector<int> &p, int u)
{
    if (p[u] == u)
        return u;
    return p[u] = find(p, p[u]);
}

class Solution
{
public:
    int makeConnected(int n, vector<vector<int>> &connections)
    {
        vector<int> p(n), sz(n, 1); // parent, size

        for (int i = 0; i < n; i++) // initializing parent array
            p[i] = i;

        int extra = 0;
        for (int i = 0; i < connections.size(); i++)
        {
            int v = connections[i][0];
            int u = connections[i][1];
            if (find(p, v) != find(p, u))
            {
                if (sz[p[v]] >= sz[p[u]])
                {
                    sz[p[v]] += sz[p[u]];
                    sz[p[u]] = 0;
                    p[p[u]] = p[v];
                }
                else
                {
                    sz[p[u]] += sz[p[v]];
                    sz[p[v]] = 0;
                    p[p[v]] = p[u];
                }
            }
            else
                extra++;
        }

        int nodes = 0;
        for (int i = 0; i < n; i++)
            if (p[i] == i)
                nodes++;

        if (nodes - 1 <= extra)
            return nodes - 1;
        else
            return -1;
    }
};

int main(void)
{
    int n = 4;
    Solution s;
    vector<vector<int>> edges = {{0, 1}, {0, 2}, {1, 2}};

    cout << s.makeConnected(n, edges) << endl;
}