#include <bits/stdc++.h>

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

using namespace std;

class Solution
{
public:
    int numIslands(vector<vector<char>> &grid)
    {
        fast_io;

        int m = grid.size(), n = grid[0].size();

        vector<vector<int>> adj_list(n * m);

        for (int i = 0; i < m - 1; i++)
        {
            int j = 0;
            for (; j < n - 1; j++)
            {
                if (grid[i][j] == '1')
                {
                    if (grid[i][j + 1] == '1')
                    {
                        adj_list[n * i + j].push_back(n * i + j + 1);
                        adj_list[n * i + j + 1].push_back(n * i + j);
                    }

                    if (grid[i + 1][j] == '1')
                    {
                        adj_list[n * i + j].push_back(n * (i + 1) + j);
                        adj_list[n * (i + 1) + j].push_back(n * i + j);
                    }
                }
            }

            if (grid[i][j] == '1')
            {
                if (grid[i + 1][j] == '1')
                {
                    adj_list[n * i + j].push_back(n * (i + 1) + j);
                    adj_list[n * (i + 1) + j].push_back(n * i + j);
                }
            }
        }

        for (int i = 0; i < n - 1; i++)
        {
            if (grid[(m - 1)][i] == '1')
            {
                if (grid[(m - 1)][i + 1] == '1')
                {
                    adj_list[n * (m - 1) + i].push_back(n * (m - 1) + i + 1);
                    adj_list[n * (m - 1) + i + 1].push_back(n * (m - 1) + i);
                }
            }
        }

        queue<int> q;
        vector<int> c(n * m, 0);
        int s, count = 0;

        for (int i = 0; i < n * m; i++)
        {
            if (c[i] == 0 && grid[i / n][i % n] == '1')
            {
                q.push(i);
                c[i] = ++count;
                while (q.empty() == 0)
                {
                    s = q.front();
                    q.pop();

                    for (auto x : adj_list[s])
                    {
                        if (c[x] == 0)
                        {
                            c[x] = count;
                            q.push(x);
                        }
                    }
                }
            }
        }

        return count;
    }
};

int main(void)
{
    Solution s;

    vector<vector<char>> grid = {{'1'}};

    cout << s.numIslands(grid) << endl;
}