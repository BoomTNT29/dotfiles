#include <bits/stdc++.h>

using namespace std;

struct segTree
{
    int size;
    vector<int> values;
    vector<int> lazy;

    void init(int n)
    {
        size = 1;
        while (size < n)
            size *= 2;
        values.resize(2 * size);
        lazy.resize(2 * size);
    }

    void build(vector<int> &nums1, int x, int lx, int rx)
    {
        if (lx == rx)
        {
            if (lx < nums1.size())
                values[x] = nums1[lx];
            return;
        }

        int m = (lx + rx) / 2;
        build(nums1, 2 * x + 1, lx, m);
        build(nums1, 2 * x + 2, m + 1, rx);

        values[x] = values[2 * x + 1] + values[2 * x + 2];
    }

    void build(vector<int> &nums1)
    {
        build(nums1, 0, 0, size - 1);
    }

    void flip(int x, int l, int r, int lx, int rx)
    {
        if (lazy[x] != 0)
        {
            values[x] = abs((rx - lx + 1) - values[x]);
            if (rx > lx)
            {
                lazy[2 * x + 1] ^= lazy[x];
                lazy[2 * x + 2] ^= lazy[x];
            }
            lazy[x] = 0;
        }

        if (rx < l || r < lx || lx > rx)
            return;

        if (l <= lx && r >= rx)
        {
            values[x] = abs((rx - lx + 1) - values[x]);
            if (lx < rx)
            {
                lazy[2 * x + 1] ^= 1;
                lazy[2 * x + 2] ^= 1;
            }
            return;
        }

        int m = (lx + rx) >> 1;
        flip(2 * x + 1, l, r, lx, m);
        flip(2 * x + 2, l, r, m + 1, rx);
        values[x] = values[2 * x + 1] + values[2 * x + 2];
        return;
    }

    void flip(int l, int r)
    {
        flip(0, l, r, 0, size - 1);
    }
};

vector<long long> handleQuery(vector<int> &nums1, vector<int> &nums2, vector<vector<int>> &queries)
{
    vector<long long> c;
    long long total = 0;
    for (auto x : nums2)
        total += x;
    segTree st;
    st.init(nums1.size());
    st.build(nums1);

    for (int i = 0; i < queries.size(); i++)
    {
        if (queries[i][0] == 1)
        {
            st.flip(queries[i][1], queries[i][2]);
        }

        if (queries[i][0] == 2)
        {
            total += queries[i][1] * st.values[0];
        }

        if (queries[i][0] == 3)
        {
            c.push_back(total);
        }
    }

    return c;
}

int main(void)
{
    vector<int> nums1 = {0, 0, 0, 0, 1, 0, 1, 1, 1};
    vector<int> nums2 = {35, 29, 21, 34, 8, 48, 22, 43, 37};
    vector<vector<int>> queries = {{1, 4, 7}, {3, 0, 0}, {2, 27, 0}, {3, 0, 0}, {1, 0, 3}, {3, 0, 0}, {2, 6, 0}, {1, 3, 8}, {2, 13, 0}, {3, 0, 0}, {3, 0, 0}, {3, 0, 0}, {2, 2, 0}, {2, 28, 0}, {3, 0, 0}, {3, 0, 0}, {2, 25, 0}, {3, 0, 0}, {3, 0, 0}, {1, 2, 5}};

    vector<long long int> c = handleQuery(nums1, nums2, queries);

    for (auto x : c)
        cout << x << ' ';
    cout << endl;
}