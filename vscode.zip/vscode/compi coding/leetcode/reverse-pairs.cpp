#include <bits/stdc++.h>

using namespace std;

struct bit
{
    int size;
    vector<long long> b;

    void init(int n)
    {
        size = n + 1;
        b.resize(size);
    }

    void update(int i, int x)
    {
        while (i < size)
        {
            b[i] += x;
            i += i & (-i);
        }
    }

    long long prefSum(int i)
    {
        int s = 0;

        while (i > 0)
        {
            s += b[i];
            i -= i & (-i);
        }

        return s;
    }
};

class Solution
{
public:
    int reversePairs(vector<int> &nums)
    {
        vector<long long> arr(nums.begin(), nums.end());
        sort(arr.begin(), arr.end());

        bit gg;
        gg.init(nums.size());

        int ans = 0;

        for (int i = 0; i < nums.size(); i++)
        {
            int index = upper_bound(arr.begin(), arr.end(), (long long)2 * (long long)nums[i]) - arr.begin(); // 0 indexed
            ans += gg.prefSum(gg.size - 1) - gg.prefSum(index);                                               // prefSum is one indexed (so implicit index - 1)
            gg.update(lower_bound(arr.begin(), arr.end(), nums[i]) - arr.begin() + 1, 1);
        }

        return ans;
    }
};

int main(void)
{
    Solution s;
    vector<int> v = {2147483647, 2147483647, 2147483647, 2147483647, 2147483647, 2147483647};
    cout << s.reversePairs(v) << endl;
}