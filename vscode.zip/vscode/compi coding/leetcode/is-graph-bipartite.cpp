#include <bits/stdc++.h>

#define fast_io              \
    ios::sync_with_stdio(0); \
    cin.tie(0);              \
    cout.tie(0);

using namespace std;

void DFS(vector<vector<int>> &adj_list, vector<int> &v, vector<int> &l, int src, int c)
{
    v[src] = 1;
    for (auto x : adj_list[src])
    {
        if (v[x] == 0)
        {
            l[x] = l[src] + 1;
            DFS(adj_list, v, l, x, c);
        }
    }
}

class Solution
{
public:
    bool isBipartite(vector<vector<int>> &graph)
    {
        fast_io;

        int n = graph.size(), count = 0;

        vector<int> v(n), l(n), c(n);

        for (int i = 0; i < n; i++)
            if (v[i] == 0)
                DFS(graph, v, l, i, count++);

        for (int i = 0; i < n; i++)
        {
            for (auto x : graph[i])
            {
                if (c[i] == c[x] && l[i] % 2 == l[x] % 2)
                    return false;
            }
        }

        return true;
    }
};

int main(void)
{
    Solution s;

    vector<vector<int>> g = {{1},
                             {0},
                             {4},
                             {4},
                             {2, 3}};

    cout << s.isBipartite(g) << endl;
}