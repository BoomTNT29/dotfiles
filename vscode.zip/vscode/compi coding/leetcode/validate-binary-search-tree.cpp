/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution
{
public:
    bool rec(TreeNode *node, long long int min, long long int max)
    {
        if (node == nullptr)
            return true;

        if (node->val <= min || node->val >= max)
            return false;

        return rec(node->left, min, node->val) && rec(node->right, node->val, max);
    }

    bool isValidBST(TreeNode *root)
    {
        return rec(root, LLONG_MIN, LLONG_MAX);
    }
};