#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    void equalize(priority_queue<double> &max,
                  priority_queue<double, vector<double>, greater<double>> &min,
                  int &maxsize, int &minsize)
    {
        while (maxsize < minsize)
        {
            max.push(min.top());
            min.pop();
            maxsize++;
            minsize--;
        }
        while (minsize < maxsize - 1)
        {
            min.push(max.top());
            max.pop();
            minsize++;
            maxsize--;
        }
        return;
    }
    vector<double> medianSlidingWindow(vector<int> &nums, int k)
    {
        vector<double> ans;
        if (k == 1)
        {
            for (int i = 0; i < nums.size(); i++)
                ans.push_back(nums[i]);

            return ans;
        }
        map<int, int> hash;
        priority_queue<double> max;
        priority_queue<double, vector<double>, greater<double>> min;
        int maxsize = 0;
        int minsize = 0;
        for (int i = 0; i < (k + 1) / 2; i++)
        {
            max.push(nums[i]);
        }
        for (int i = 0; i < k / 2; i++)
        {
            min.push(nums[i]);
        }
        for (int i = (k + 1) / 2; i < k; i++)
        {
            if (nums[i] < max.top())
            {
                max.pop();
                max.push(nums[i]);
            }
        }
        for (int i = k / 2; i < k; i++)
        {
            if (nums[i] > min.top())
            {
                min.pop();
                min.push(nums[i]);
            }
        }
        maxsize = max.size();
        minsize = min.size();
        for (int i = k; i < nums.size(); i++)
        {
            while (max.size() + min.size() > k && hash[max.top()] > 0)
            {
                hash[max.top()]--;
                max.pop();
            }
            while (max.size() + min.size() > k && hash[min.top()] > 0)
            {
                hash[min.top()]--;
                min.pop();
            }
            if (k % 2)
                ans.push_back(1.0 * max.top());
            else
                ans.push_back(1.0 * (max.top() + min.top()) / 2);
            if (nums[i - k] == max.top())
            {
                max.pop();
                maxsize--;
            }
            else if (nums[i - k] == min.top())
            {
                min.pop();
                minsize--;
            }
            else
                hash[nums[i - k]]++;
            if (nums[i - k] < max.top())
                maxsize--;
            else if (nums[i - k] > min.top())
                minsize--;
            if (nums[i] < max.top())
            {
                max.push(nums[i]);
                maxsize++;
            }
            else
            {
                min.push(nums[i]);
                minsize++;
            }
            equalize(max, min, maxsize, minsize);
        }
        if (k % 2)
            ans.push_back((1.0) * max.top());
        else
            ans.push_back(1.0 * (max.top() + min.top()) / 2);
        return ans;
    }
};

auto init = []()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    return 'c';
}();

int main(void)
{
}