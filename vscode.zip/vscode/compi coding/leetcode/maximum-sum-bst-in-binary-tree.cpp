/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left),
 * right(right) {}
 * };
 */
class Solution
{
public:
    // {min, max, sum, maxSum, flag}
    vector<int> rec(TreeNode *root)
    {

        if (root == nullptr)
            return {0, 0, 0, 0, 2};
        if (root->left == nullptr && root->right == nullptr)
            return {root->val, root->val, root->val, root->val, 1};

        vector<int> lt = rec(root->left);
        vector<int> rt = rec(root->right);

        cout << root->val << endl
             << endl;

        if (lt[4] == 2)
        {
            lt = {root->val, root->val - 1, 0, INT_MIN, 1};
        }

        if (rt[4] == 2)
        {
            rt = {root->val + 1, root->val, 0, INT_MIN, 1};
        }

        if (lt[4] == 0 || rt[4] == 0 || lt[1] >= root->val ||
            rt[0] <= root->val)
            return {min(root->val, min(lt[0], rt[0])),
                    max(root->val, max(rt[1], lt[1])), max(lt[2], rt[2]),
                    max(lt[3], rt[3]), 0};

        return {min(root->val, min(lt[0], rt[0])),
                max(max(root->val, rt[1]), lt[1]), lt[2] + rt[2] + root->val,
                max(lt[3], max(rt[3], lt[2] + rt[2] + root->val)), 1};
    }

    int maxSumBST(TreeNode *root)
    {
        vector<int> l = rec(root);
        return max(max(l[2], l[3]), 0);
    }
};