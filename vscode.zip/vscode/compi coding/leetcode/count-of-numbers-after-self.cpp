class Solution
{
public:
    int prefixSum(vector<int> &bit, int n, int i)
    {
        int s = 0;
        i--;
        while (i > 0)
        {
            s += bit[i];
            i -= i & (-i);
        }

        return s;
    }

    void update(vector<int> &bit, int n, int i, int x)
    {
        while (i < n + 1)
        {
            bit[i] += x;
            i += i & (-i);
        }
    }

    vector<int> countSmaller(vector<int> &nums)
    {
        int n = nums.size();
        vector<int> bit(n + 1);
        vector<int> b(nums.begin(), nums.end());
        sort(b.begin(), b.end());

        vector<int> c(n);

        int j;
        for (int i = n - 1; i > -1; i--)
        {
            j = distance(b.begin(), lower_bound(b.begin(), b.end(), nums[i])) + 1;
            c[i] = prefixSum(bit, n, j);
            update(bit, n, j, 1);
        }

        return c;
    }
};