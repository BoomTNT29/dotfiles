/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution
{
public:
    int i = 0;

    TreeNode *rec(vector<int> &preorder, int bound)
    {
        if (i >= preorder.size() || preorder[i] > bound)
            return nullptr;

        TreeNode *res = new TreeNode(preorder[i]);
        i++;
        res->left = rec(preorder, preorder[i - 1]);
        res->right = rec(preorder, bound);
        return res;
    }

    TreeNode *bstFromPreorder(vector<int> &preorder)
    {
        return rec(preorder, INT_MAX);
    }
};