#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    int prefixSum(vector<int> &bit, int n, int i)
    {
        int s = 0;

        while (i > 0)
        {
            s += bit[i];
            i -= i & (-i);
        }

        return s;
    }

    void update(vector<int> &bit, int n, int i, int x)
    {
        while (i < n + 1)
        {
            bit[i] += x;
            i += i & (-i);
        }
    }

    int numTeams1(vector<int> &rating)
    {
        int n = rating.size();
        vector<int> bit1(n + 1), bit2(n + 1), b(rating.begin(), rating.end());
        vector<pair<int, int>> c(n), d(n);
        sort(b.begin(), b.end());

        int ans = 0, j, k;
        pair<int, int> s1, s2;

        for (int i = 0; i < n; i++)
        {
            j = distance(b.begin(), lower_bound(b.begin(), b.end(), rating[i])) + 1;
            k = distance(b.begin(), lower_bound(b.begin(), b.end(), rating[n - i - 1])) + 1;
            s1 = {prefixSum(bit1, n, j - 1), prefixSum(bit1, n, j)};
            s2 = {prefixSum(bit2, n, k - 1), prefixSum(bit2, n, k)};

            c[i] = s1;
            d[n - i - 1] = s2;

            update(bit1, n, j, 1);
            update(bit2, n, k, 1);
        }

        for (int i = 0; i < n; i++)
        {
            ans += (c[i].first) * ((n - i - 1) - d[i].second);
        }

        return ans;
    }

    int numTeams(vector<int> &rating)
    {
        vector<int> a(rating.rbegin(), rating.rend());
        return numTeams1(rating) + numTeams1(a);
    }
};