#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    int numSmallest(vector<vector<int>> &matrix, int num)
    {
        int col = 0, row = matrix.size() - 1, count = 0;

        for (col = 0; col < matrix.size(); col++)
        {
            while (row > 0 && matrix[row][col] > num)
                row--;

            if (matrix[row][col] <= num)
                count += row + 1;
        }

        return count;
    }

    int kthSmallest(vector<vector<int>> &matrix, int k)
    {
        int low = matrix[0][0];
        int high = matrix[matrix.size() - 1][matrix.size() - 1];
        int middle, ans = 0, num;
        while (low <= high)
        {
            middle = (high - low) / 2 + low;
            num = numSmallest(matrix, middle);

            if (num < k)
                low = middle + 1;
            else if (num >= k)
            {
                ans = middle;
                high = middle - 1;
            }
        }

        return ans;
    }
};