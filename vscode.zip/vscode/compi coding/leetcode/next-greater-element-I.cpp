#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    vector<int> nextGreaterElement(vector<int> &nums1, vector<int> &nums2)
    {
        stack<int> st;
        vector<int> partialAns(nums2.size());
        map<int, int> amap;

        for (int i = 0; i < nums2.size(); i++)
        {
            while (!st.empty() && nums2[st.top()] < nums2[i])
            {
                partialAns[st.top()] = i;
                st.pop();
            }

            st.push(i);
            amap[nums2[i]] = i;
        }

        while (!st.empty())
        {
            partialAns[st.top()] = -1;
            st.pop();
        }

        vector<int> ans;

        for (int i = 0; i < nums1.size(); i++)
        {
            if (amap.find(nums1[i]) != amap.end() && partialAns[amap[nums1[i]]] != -1)
                ans.push_back(nums2[partialAns[amap[nums1[i]]]]);
            else if (amap.find(nums1[i]) != amap.end())
                ans.push_back(-1);
        }

        return ans;
    }
};