#include <bits/stdc++.h>

using namespace std;

class StockSpanner
{
public:
    stack<pair<int, int>> st;
    int index = 0;

    StockSpanner()
    {
    }

    int next(int price)
    {
        int count = 0;
        index++;
        while (!st.empty() && st.top().first <= price)
            st.pop();

        if (st.empty())
            count = index;
        else
            count = index - st.top().second;

        st.push({price, index});
        return count;
    }
};

/**
 * Your StockSpanner object will be instantiated and called as such:
 * StockSpanner* obj = new StockSpanner();
 * int param_1 = obj->next(price);
 */