#include <bits/stdc++.h>

using namespace std;

struct item
{
    char cPref, cSuf, cMax;
    int cPrefCount, cSufCount, cMaxCount;
};

struct segTree
{
    int size;
    vector<item> values;

    void init(int n)
    {
        size = 1;
        while (size < n)
            size *= 2;
        values.resize(size * 2);
    }

    void merge(int x, int l, int r, int m)
    {
        values[x].cPref = values[2 * x + 1].cPref;

        if (values[2 * x + 1].cPrefCount == (m - l + 1) && values[2 * x + 2].cPref == values[2 * x + 1].cPref)
            values[x].cPrefCount = values[2 * x + 1].cPrefCount + values[2 * x + 2].cPrefCount;
        else
            values[x].cPrefCount = values[2 * x + 1].cPrefCount;

        values[x].cSuf = values[2 * x + 2].cSuf;

        if (values[2 * x + 2].cSufCount == (r - m) && values[2 * x + 1].cSuf == values[2 * x + 2].cSuf)
            values[x].cSufCount = values[2 * x + 2].cSufCount + values[2 * x + 1].cSufCount;
        else
            values[x].cSufCount = values[2 * x + 2].cSufCount;

        values[x].cMaxCount = max(values[2 * x + 1].cMaxCount, values[2 * x + 2].cMaxCount);
        values[x].cMax = max(values[2 * x + 1].cMaxCount, values[2 * x + 2].cMaxCount) == values[2 * x + 1].cMaxCount ? values[2 * x + 1].cMax : values[2 * x + 2].cMax;

        if (values[2 * x + 1].cSuf == values[2 * x + 2].cPref && values[x].cMaxCount < values[2 * x + 1].cSufCount + values[2 * x + 2].cPrefCount)
        {
            values[x].cMaxCount = values[2 * x + 1].cSufCount + values[2 * x + 2].cPrefCount;
            values[x].cMax = values[2 * x + 1].cSuf;
        }
    }

    void build(string &s, int x, int l, int r)
    {
        if (l == r)
        {
            if (l < s.size())
            {
                values[x] = {s[l], s[l], s[l], 1, 1, 1};
            }
            return;
        }

        int m = (l + r) >> 1;
        build(s, 2 * x + 1, l, m);
        build(s, 2 * x + 2, m + 1, r);
        merge(x, l, r, m);
    }

    void build(string &s)
    {
        build(s, 0, 0, size - 1);
    }

    void set(char c, int i, int x, int lx, int rx)
    {
        if (lx == rx)
        {
            values[x] = {c, c, c, 1, 1, 1};
            return;
        }

        int m = (lx + rx) / 2;
        if (m < i)
            set(c, i, 2 * x + 2, m + 1, rx);
        else
            set(c, i, 2 * x + 1, lx, m);
        merge(x, lx, rx, m);
    }

    void set(char c, int i)
    {
        set(c, i, 0, 0, size - 1);
    }
};

class Solution
{
public:
    vector<int> longestRepeating(string &s, string queryCharacters, vector<int> &queryIndices)
    {
        segTree st;
        vector<int> ans;
        st.init(s.size());
        st.build(s);

        for (int i = 0; i < queryIndices.size(); i++)
        {
            st.set(queryCharacters[i], queryIndices[i]);
            ans.push_back(st.values[0].cMaxCount);
        }

        return ans;
    }
};

int main(void)
{
    Solution x;

    string s = "abyzz", queryCharacters = "aa";
    vector<int> queryIndices = {2, 1};

    vector<int> ans = x.longestRepeating(s, queryCharacters, queryIndices);

    for (auto x : ans)
        cout << x << ' ';
    cout << endl;
}
