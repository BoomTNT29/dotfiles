/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution
{
public:
    TreeNode *rec(TreeNode *root, int low, int high)
    {
        if (root == nullptr)
            return root;

        if (root->val < low)
            return rec(root->right, low, high);

        if (root->val > high)
            return rec(root->left, low, high);

        root->left = rec(root->left, low, high);
        root->right = rec(root->right, low, high);
        return root;
    }

    TreeNode *trimBST(TreeNode *root, int low, int high)
    {
        return rec(root, low, high);
    }
};