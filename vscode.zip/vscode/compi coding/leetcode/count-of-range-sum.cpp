#include <bits/stdc++.h>

using namespace std;

struct segTree
{
    int size;
    vector<int> values;

    void init(int n)
    {
        size = 1;
        while (size < n)
            size *= 2;
        values.assign(2 * size, 0);
    }

    void update(int x, int i)
    {
        values[size + i - 1] += x;
        i = size + i - 1;
        i = (i - 1) >> 1;
        while (i >= 0)
        {
            values[i] = values[i * 2 + 1] + values[2 * i + 2];
            i = (i - 1) >> 1;
        }
    }

    int rangeSum(int l, int r, int lx, int rx, int i)
    {
        if (l <= lx && r >= rx)
            return values[i];

        if (r < lx || l > rx)
            return 0;

        int m = (lx + rx) / 2;

        int m1 = rangeSum(l, r, lx, m, (2 * i + 1));
        int m2 = rangeSum(l, r, m + 1, rx, (2 * i + 2));

        return m1 + m2;
    }

    int rangeSum(int l, int r)
    {
        return rangeSum(l, r, 0, size - 1, 0);
    }
};

class Solution
{
public:
    int countRangeSum(vector<int> &nums, int lower, int upper)
    {
        vector<int> prefSum, prefSumSorted;
        int s = 0;
        segTree st;
        st.init(nums.size());

        for (auto x : nums)
        {
            s += x;
            prefSum.push_back(s);
            prefSumSorted.push_back(s);
        }

        sort(prefSumSorted.begin(), prefSumSorted.end());

        int ans = 0;

        for (int i = prefSum.size() - 1; i > -1; i--)
        {
            st.update(1, distance(prefSumSorted.begin(), lower_bound(prefSumSorted.begin(), prefSumSorted.end(), prefSum[i])));
            int l = distance(prefSumSorted.begin(), lower_bound(prefSumSorted.begin(), prefSumSorted.end(), lower + (i == 0 ? 0 : prefSum[i - 1])));
            int u = distance(prefSumSorted.begin(), upper_bound(prefSumSorted.begin(), prefSumSorted.end(), upper + (i == 0 ? 0 : prefSum[i - 1]))) - 1;
            ans += st.rangeSum(l, u);
            cout << st.rangeSum(l, u) << endl;
            cout << l << ' ' << u << endl;
        }

        return ans;
    }
};

int main(void)
{
    Solution x;
    vector<int> v = {0, 0};
    cout << x.countRangeSum(v, 0, 0) << endl;
}