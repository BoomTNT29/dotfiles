#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    long long putMarbles(vector<int> &weights, int k)
    {
        priority_queue<long long int> maxheap;
        priority_queue<int, vector<int>, greater<int>> minheap;

        for (int i = 1; i < weights.size(); i++)
        {
            maxheap.push(weights[i - 1] + weights[i]);
            minheap.push(weights[i - 1] + weights[i]);
        }

        long long int ans = 0;

        for (int i = 0; i < k - 1; i++)
        {
            ans += maxheap.top() - minheap.top();
            maxheap.pop();
            minheap.pop();
        }

        return ans;
    }
};

auto init = []()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    return 'c';
}();