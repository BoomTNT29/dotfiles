#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    vector<int> DIR = {0, -1, 0, 1, 0};

    void dfs(vector<vector<int>> &grid, int x, int y, int &count)
    {
        grid[x][y] = 1;
        count++;

        for (int i = 0; i < 4; i++)
        {
            int ni = x + DIR[i], nj = y + DIR[i + 1];

            if (ni < 0 || ni == grid.size() || nj < 0 || nj == grid[0].size() || grid[ni][nj] != -1)
                continue;

            dfs(grid, ni, nj, count);
        }
    }

    vector<int> hitBricks(vector<vector<int>> &grid, vector<vector<int>> &hits)
    {
        for (auto &x : hits)
            if (grid[x[0]][x[1]] == 1)
                grid[x[0]][x[1]] = 0;
            else
                grid[x[0]][x[1]] = -2;

        queue<pair<int, int>> pq;

        for (int i = 0; i < grid[0].size(); i++)
            if (grid[0][i] == 1)
                pq.emplace(make_pair(0, i));

        for (int i = 1; i < grid.size(); i++)
            for (int j = 0; j < grid[0].size(); j++)
                if (grid[i][j] == 1)
                    grid[i][j] = -1;

        while (!pq.empty())
        {
            int x = pq.front().first, y = pq.front().second;
            pq.pop();

            for (int i = 0; i < 4; i++)
            {
                int ni = x + DIR[i], nj = y + DIR[i + 1];

                if (ni < 0 || ni == grid.size() || nj < 0 || nj == grid[0].size() || grid[ni][nj] != -1)
                    continue;

                grid[ni][nj] = 1;
                pq.emplace(make_pair(ni, nj));
            }
        }

        vector<int> ans(hits.size());
        int it = hits.size() - 1;
        while (it > -1)
        {
            if (grid[hits[it][0]][hits[it][1]] == -2)
            {
                grid[hits[it][0]][hits[it][1]] = 0;
                int count = 0;
                ans[it] = count;
                it--;
                continue;
            }

            bool flag = false;
            if (hits[it][0] == 0)
                flag = true;

            for (int i = 0; (i < 4) && !flag; i++)
            {
                int ni = hits[it][0] + DIR[i], nj = hits[it][1] + DIR[i + 1];

                if (ni < 0 || ni == grid.size() || nj < 0 || nj == grid[0].size())
                    continue;

                if (grid[ni][nj] == 1)
                    flag = true;

                if (flag)
                    break;
            }

            int count = -1;
            if (flag)
                dfs(grid, hits[it][0], hits[it][1], count);

            else
            {
                grid[hits[it][0]][hits[it][1]] = -1;
                count = 0;
            }

            ans[it] = count;
            it--;
        }

        return ans;
    }
};

int main(void)
{
    vector<vector<int>> grid = {{1}, {1}, {1}, {1}, {1}};
    vector<vector<int>> hits = {{3, 0}, {4, 0}, {1, 0}, {2, 0}, {0, 0}};

    Solution s;

    vector<int> ans = s.hitBricks(grid, hits);

    for (auto x : ans)
        cout << x << ' ';
    cout << endl;
}