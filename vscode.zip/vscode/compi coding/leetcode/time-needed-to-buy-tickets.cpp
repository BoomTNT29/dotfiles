#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    int timeRequiredToBuy(vector<int> &tickets, int k)
    {
        int answer = 0;

        for (int i = 0; i < tickets.size(); i++)
        {
            if (tickets[i] >= tickets[k] && i <= k)
                answer += tickets[k];
            else if (tickets[i] >= tickets[k] - 1)
                answer += tickets[k] - 1;
            else
                answer += tickets[i];
        }

        return answer;
    }
};