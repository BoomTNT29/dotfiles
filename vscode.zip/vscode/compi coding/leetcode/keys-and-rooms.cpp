#define fast_io              \
    ios::sync_with_stdio(0); \
    cin.tie(0);              \
    cout.tie(0);

void dfs(vector<vector<int>> &rooms, vector<int> &visited, int src)
{
    visited[src] = 1;
    for (auto x : rooms[src])
    {
        if (visited[x] == 0)
            dfs(rooms, visited, x);
    }
}

class Solution
{
public:
    bool canVisitAllRooms(vector<vector<int>> &rooms)
    {
        fast_io;

        vector<int> visited(rooms.size());

        dfs(rooms, visited, 0);

        for (auto x : visited)
            if (x == 0)
                return false;

        return true;
    }
};