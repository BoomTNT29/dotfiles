#include <bits/stdc++.h>

using namespace std;

int find(vector<int> &p, int u)
{
    if (p[u] == u)
        return u;
    return p[u] = find(p, p[u]);
}

class Solution
{
public:
    int minCostConnectPoints(vector<vector<int>> &points)
    {
        int n = points.size(), cost = 0;
        vector<int> v(n), d(n), p(n), sz(n, 1);
        vector<pair<int, pair<int, int>>> edges;

        for (int i = 0; i < n; i++)
        {
            p[i] = i;
            for (int j = i + 1; j < n; j++)
                edges.push_back(make_pair(abs(points[i][0] - points[j][0]) + abs(points[i][1] - points[j][1]), make_pair(i, j)));
        }

        sort(edges.begin(), edges.end());

        for (int i = 0; i < edges.size(); i++)
        {
            int v = edges[i].second.first, u = edges[i].second.second, c = edges[i].first;
            if (find(p, v) != find(p, u))
            {
                if (sz[p[v]] >= sz[p[u]])
                {
                    sz[p[v]] += sz[p[u]];
                    sz[p[u]] = 0;
                    p[p[u]] = p[v];
                }
                else
                {
                    sz[p[u]] += sz[p[v]];
                    sz[p[v]] = 0;
                    p[p[v]] = p[u];
                }

                cost += c;
            }
        }

        return cost;
    }
};