#include <bits/stdc++.h>

using namespace std;

class Solution
{
public:
    bool isValid(string s)
    {
        vector<char> st;
        int i;

        for (i = 0; i < s.size(); i++)
        {
            if (s[i] == '}')
            {
                if (st.size() && st.back() == '{')
                    st.pop_back();
                else
                    break;
            }
            else if (s[i] == ')')
            {
                if (st.size() && st.back() == '(')
                    st.pop_back();
                else
                    break;
            }
            else if (st.size() && s[i] == ']')
            {
                if (st.back() == '[')
                    st.pop_back();
                else
                    break;
            }
            else
            {
                st.push_back(s[i]);
            }
        }

        if (i == s.size() && st.size() == 0)
            return true;
        else
            return false;
    }
};