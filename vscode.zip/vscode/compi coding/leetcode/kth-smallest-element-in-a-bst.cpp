/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution
{
public:
    int val = 0;
    bool flag = false;
    int recur(TreeNode *root, int k)
    {
        if (root == nullptr || flag)
            return k;

        k = recur(root->left, k);
        if (k == 1)
        {
            val = root->val;
            flag = true;
        }
        return recur(root->right, k - 1);
    }

    int kthSmallest(TreeNode *root, int k)
    {
        recur(root, k);
        return val;
    }
};