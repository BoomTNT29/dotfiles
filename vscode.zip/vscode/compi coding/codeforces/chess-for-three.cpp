#include <bits/stdc++.h>

using namespace std;

int main(void)
{
    int t;
    cin >> t;
    while (t--)
    {
        int p1, p2, p3;
        cin >> p1 >> p2 >> p3;

        cout << ((p1 + p2 + p3) % 2 ? -1 : min((p1 + p2 + p3) / 2, p1 + p2)) << endl;
    }
}