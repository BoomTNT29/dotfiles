#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int t;
    cin >> t;

    while (t--)
    {
        string a, b;
        cin >> a >> b;

        swap(a[0], b[0]);

        cout << a << ' ' << b << endl;        
    }
}