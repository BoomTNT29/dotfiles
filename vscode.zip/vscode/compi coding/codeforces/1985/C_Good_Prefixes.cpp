#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        ll n;
        cin >> n;

        vector<ll> a(n);
        for (ll i = 0; i < n; i++)
        {
            cin >> a[i];
        }

        ll sum1 = 0, ans = 0, max1 = 0;
        for (ll i = 0; i < n; i++)
        {
            sum1 += a[i];

            if (max1 < a[i])
                max1 = a[i];

            if (sum1 - max1 == max1)
                ans++;
        }

        cout << ans << endl;
    }
}