#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        ll health, moves;
        cin >> health >> moves;

        vector<ll> damage(moves);
        vector<ll> cooldown(moves);

        for (ll i = 0; i < moves; i++)
        {
            cin >> damage[i];
        }
        for (ll i = 0; i < moves; i++)
        {
            cin >> cooldown[i];
        }

        priority_queue<pair<ll, ll>, vector<pair<ll, ll>>, greater<pair<ll, ll>>> q;
        for (ll i = 0; i < moves; i++)
        {
            q.push(make_pair(1, i)); // left is turn, right is move
        }

        ll turnno;
        while (health > 0)
        {
            turnno = q.top().first;

            while (!q.empty() && q.top().first == turnno)
            {
                ll move = q.top().second;
                health -= damage[move];
                q.pop();

                q.push(make_pair(turnno + cooldown[move], move));
            }
        }
        cout << turnno << endl;
    }
}