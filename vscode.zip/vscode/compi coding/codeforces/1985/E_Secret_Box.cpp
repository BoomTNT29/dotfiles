#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        ll x, y, z, k;
        cin >> x >> y >> z >> k;

        ll sols = 0;
        for (ll i = 1; i <= x; i++)
        {
            for (ll j = 1; j <= y; j++)
            {
                if (k % (i * j) == 0 && z >= k / (i * j))
                {
                    sols = max(sols, (x - i + 1) * (y - j + 1) * (z - (k / (i * j)) + 1));
                }
            }
        }

        cout << sols << endl;
    }
}