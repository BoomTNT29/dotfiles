#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

pair<int, int> calc(vector<vector<char>> &grid, int n, int m, int i, int j)
{
    pair<int, int> p1 = {i, j}, p2 = {i, j};

    while (p1.first - 1 >= 0 && p1.second + 1 < m && grid[p1.first - 1][p1.second + 1] == '#')
    {
        p1.first--;
        p1.second++;
    }

    while (p2.first + 1 < n && p2.second - 1 >= 0 && grid[p2.first + 1][p2.second - 1] == '#')
    {
        p2.first++;
        p2.second--;
    }

    return pair<int, int>{p2.first, p1.second};
}

int main(void)
{
    int t;
    cin >> t;

    while (t--)
    {
        int n, m;
        cin >> n >> m;

        vector<char> temp(m);
        vector<vector<char>> grid(n, temp);

        for (auto &x : grid)
            for (auto &y : x)
                cin >> y;

        pair<int, int> ans = {-1, -1};
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (grid[i][j] == '#')
                {
                    ans = calc(grid, n, m, i, j);
                    break;
                }
            }
            if (ans.first != -1)
                break;
        }

        cout << ans.first + 1 << ' ' << ans.second + 1 << endl;
    }
}