#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int t;
    cin >> t;

    while (t--)
    {
        int n;
        cin >> n;

        if (n == 3)
            cout << 3 << endl;
        else
            cout << 2 << endl;
    }
}