#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    int n = 1, m;
    cin >> n >> m;

    vll temp(m, 0);
    vvll grid(n, temp);

    for (auto &x : grid)
        for (auto &y : x)
            cin >> y;

    vll DIR = {0, 1, 0, -1, 0};

    int x, y;
    fr(i, n)
    {
        fr(j, m)
        {
            ll max1 = -1;
            fr(k, 4)
            {
                x = i + DIR[k], y = j + DIR[k + 1];

                if (x < 0 || y < 0 || x >= n || y >= m)
                {
                    continue;
                }

                max1 = max(grid[x][y], max1);
            }

            grid[i][j] = min(max1, grid[i][j]);
        }
    }

    for (auto &i : grid)
    {
        for (auto &x : i)
        {
            cout << x << " ";
        }
        nl;
    }
}

int main(void)
{
    fast_io;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}