#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << x << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));
#define maxn 1000005
ll pre[maxn], suf[maxn];

ll sol1(vll o, int k)
{
    ll now = 0;
    for (int i = 0; i + 1 < sz(o); i += 2)
        now += (o[i + 1] - o[i]) / k, pre[i] = now;
    now = 0;
    for (int i = sz(o) - 1; i >= 1; i -= 2)
        now += (o[i] - o[i - 1]) / k, suf[i] = now;
    ll res = 1e18;
    rep(i, 0, sz(o) - 1)
    {
        if (i % 2 == 0)
        {
            ll tmp = 0;
            if (i != 0)
                tmp += pre[i - 2];
            if (i != sz(o) - 1)
                tmp += suf[i + 2];
            res = min(res, tmp);
        }
    }
    return res;
}

void solve(void)
{
    ll n = 1, k;
    cin >> n >> k;

    vll a(n);
    map<ll, vll> seperations;
    fr(i, n)
    {
        cin >> a[i];
        seperations[a[i] % k].push_back(a[i]);
    }

    int flag = n % 2;
    ll answer = 0;
    for (auto &x : seperations)
    {
        if (x.second.size() % 2 == 0)
        {
            srt(x.second);
            fr(j, x.second.size() - 1)
            {
                answer += (x.second[j + 1] - x.second[j]) / k;
                j++;
            }
        }
        else if (x.second.size())
        {
            if (flag)
                flag = 1 - flag;
            else
            {
                cout << -1 << endl;
                return;
            }
            srt(x.second);
            // vll diffArr, diffArr2;
            // fr(j, x.second.size() - 1)
            // {
            //     diffArr.push_back(x.second[j + 1] - x.second[j]);
            //     j++;
            // }

            // rep(j, 1, x.second.size() - 2)
            // {
            //     diffArr2.push_back(x.second[j + 1] - x.second[j]);
            //     j++;
            // }

            // srt(diffArr);
            // srt(diffArr2);
            // ll temp1 = 0, temp2 = 0;
            // fr(i, diffArr.size())
            //     temp1 += diffArr[i] / k;
            // fr(i, diffArr2.size())
            //     temp2 += diffArr2[i] / k;

            // answer += min(temp1, temp2);

            answer += sol1(x.second, k);
        }
    }

    cout << answer << endl;
}

int main(void)
{
    fast_io;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}