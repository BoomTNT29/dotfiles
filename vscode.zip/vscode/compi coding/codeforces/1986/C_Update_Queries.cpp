#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << x << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    int n = 1, m;
    cin >> n >> m;

    string s;
    cin >> s;

    vi ind(m);
    fr(i, m)
        cin >> ind[i];
    
    vector<char> c(m);
    fr(i, m)
        cin >> c[i];
    
    srt(ind);
    srt(c);

    int cpointer = m;

    fr(i, m - 1)
        if (ind[i] == ind[i + 1])
            ind[i] = -1, cpointer--;
    
    int j = 0;
    fr(i, cpointer)
    {
        while (ind[j] == -1)
            j++;

        s[ind[j] - 1] = c[i];
        j++;
    }

    cout << s;
    nl;
}

int main(void)
{
    fast_io;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}