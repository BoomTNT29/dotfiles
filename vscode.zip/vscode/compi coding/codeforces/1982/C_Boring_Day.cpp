#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << x << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    ll n, l, r = 1;
    cin >> n >> l >> r;

    vll a(n);
    fr(i, n)
            cin >>
        a[i];

    ll sum = a[0], answer = 0, p1 = 0, p2 = 1;

    while (p2 <= n)
    {
        if (p2 > p1 && (sum <= r && sum >= l))
        {
            answer++;
            sum = 0;
            p1 = p2;
        }
        else if (p2 > p1 && sum > r)
        {
            sum -= a[p1++];
        }
        else
        {
            sum += a[p2++];
        }
    }

    cout << answer << endl;
}

int main(void)
{
    fast_io;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}