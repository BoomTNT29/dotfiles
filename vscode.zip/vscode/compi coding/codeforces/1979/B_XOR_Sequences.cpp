#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int n;
    cin >> n;

    while (n--)
    {
        ll x, y;
        cin >> x >> y;

        ll answer = 1;
        while ((x & 1) == (y & 1))
        {
            answer *= 2;
            x = x >> 1;
            y = y >> 1;
        }

        cout << answer << endl;
    }
}