#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        ll n;
        cin >> n;

        vector<ll> a(n);

        for (auto &x : a)
            cin >> x;
        
        ll answer = LONG_LONG_MAX;
        for (ll i = 0; i < n-1; i++)
        {
            if (answer >= max(a[i], a[i+1]))
                answer = max(a[i], a[i+1]) - 1;
        }

        cout << answer << endl;
    }
}