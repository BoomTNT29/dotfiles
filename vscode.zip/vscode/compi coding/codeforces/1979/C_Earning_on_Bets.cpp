#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

ll gcd(ll a, ll b)
{
    while (b != 0)
    {
        ll tmp = a % b;
        a = b;
        b = tmp;
    }
    return a;
}

ll lcm(ll a, ll b)
{
    return (a * b) / gcd(a, b);
}

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        ll n;
        cin >> n;

        vector<ll> k(n);
        for (ll i = 0; i < n; i++)
        {
            cin >> k[i];
        }

        ll lcm1 = 1;
        for (ll i = 0; i < n; i++)
        {
            lcm1 = lcm(lcm1, k[i]);
        }

        ll sum1 = 0;
        for (ll i = 0; i < n; i++)
        {
            sum1 += lcm1 / k[i];
        }

        if (sum1 < lcm1)
        {
            for (ll i = 0; i < n; i++)
                cout << lcm1 / k[i] << ' ';
            cout << endl;
        }
        else
            cout << -1 << endl;
    }
}