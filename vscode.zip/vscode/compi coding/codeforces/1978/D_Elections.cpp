#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var)         \
    for (auto &i : var)   \
    {                     \
        cout << i << " "; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    int n = 1, c;
    cin >> n >> c;

    vll voters(n);
    int maxIndex = 0;
    fr(i, n)
    {
        cin >> voters[i];
        if (voters[i] > voters[maxIndex])
            maxIndex = i;
    }

    if (voters[0] + c >= voters[maxIndex])
        maxIndex = 0;
    
    vi ans(n);
    ll frontSum = 0;
    
    fr(i, n)
    {
        if (i < maxIndex)
            if (frontSum + c + voters[i] >= voters[maxIndex])
                ans[i] = i;
            else
                ans[i] = i + 1;
        else if (i == maxIndex)
            ans[i] = 0;
        else
            ans[i] = i;
        
        frontSum += voters[i];
    }

    dbgv(ans);
    nl;
}

int main(void)
{
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}