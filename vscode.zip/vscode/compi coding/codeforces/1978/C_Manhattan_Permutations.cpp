#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

// ##################################ORDERED SET AND MULTISET########################################
#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp>     // Including tree_order_statistics_node_update
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
typedef tree<int, null_type, less_equal<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_multiset;
// ##################################################################################################

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl;
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var)         \
    for (auto &i : var)   \
    {                     \
        cout << i << " "; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    ll n = 1, k;
    cin >> n >> k;

    ll maxK = (n * n) / (ll)2;

    vi ans(n);
    fr(i, n)
    {
        ans[i] = i + 1;
    }
    
    if (k % 2 || k > maxK)
    {
        cout << "No" << endl;
        return;
    }

    ll front = 1, back = n;
    set<ll> fin;
    while (k > 0)
    {
        if (k >= 2 * (back - front))
        {
            k -= 2 * (back - front);
            fin.insert(back);
            fin.insert(front);
            swap(ans[front - 1], ans[back - 1]);
            front++;
            back--;
        }
        else
        {
            k /= 2;
            swap(ans[front - 1], ans[k + front - 1]);
            k = 0;
        }
    }

    cout << "Yes" << endl;
    dbgv(ans);
    nl;
}

int main(void)
{
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}