#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int t;
    cin >> t;

    while (t--)
    {
        int n, m;
        cin >> n >> m;

        int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0;

        for (int i = 0; i < n; i++)
        {
            char x;
            cin >> x;

            switch (x)
            {
            case 'A':
                a++;
                break;
            case 'B':
                b++;
                break;
            case 'C':
                c++;
                break;
            case 'D':
                d++;
                break;
            case 'E':
                e++;
                break;
            case 'F':
                f++;
                break;
            case 'G':
                g++;
                break;
            default:
                break;
            }
        }
        int answer = max(0, m - a) + max(0, m - b) + max(0, m - c) + max(0, m - d) + max(0, m - e) + max(0, m - f) + max(0, m - g);
        cout << answer << endl;
    }
}