#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    int t;
    cin >> t;

    while (t--)
    {
        int n, f, k, val;
        cin >> n >> f >> k;

        vector<int> a;
        for (int i = 0; i < n; i++)
        {
            int temp;
            cin >> temp;
            a.push_back(temp);

            if (i == f - 1)
                val = temp;
        }

        sort(a.begin(), a.end());

        int end = distance(lower_bound(a.begin(), a.end(), val), a.end());
        int st = distance(upper_bound(a.begin(), a.end(), val), a.end()) + 1;

        // cout << end << ' ' << st << endl;
        if (k >= st)
            if (st != end && k < end)
                cout << "MAYBE" << endl;
            else
                cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}