#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

bool check(vector<ll> gcda, vector<ll> &gcda2, int ind)
{
    if (ind == 0)
        gcda[0] = gcda[1];
    else
    {
        if (ind != gcda.size())
            gcda[ind] = gcda[ind - 1] = gcda2[ind - 1];
        else
            gcda[ind - 1] = gcda[ind - 2];
    }

    bool flag = true;

    for (int i = 0; i < gcda.size() - 1 && flag; i++)
        if (gcda[i] > gcda[i + 1])
            flag = false;

    return flag;
}

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        int n;
        cin >> n;

        vector<ll> a(n);
        for (auto &x : a)
            cin >> x;

        vector<ll> gcda, gcda2;
        for (int i = 1; i < n; i++)
            gcda.push_back(__gcd(a[i - 1], a[i]));

        for (int i = 2; i < n; i++)
            gcda2.push_back(__gcd(a[i - 2], a[i]));

        int ind = -1;
        bool flag = true;

        for (int i = 0; i < n - 1 && ind == -1; i++)
            if (gcda[i] > gcda[i + 1])
                ind = i;

        if (ind != -1)
        {
            if (ind == 0)
                flag = check(gcda, gcda2, ind) || check(gcda, gcda2, ind + 1) || check(gcda, gcda2, ind + 2);
            else if (ind == n - 2)
                flag = check(gcda, gcda2, ind + 1) || check(gcda, gcda2, ind) || check(gcda, gcda2, ind - 1);
            else
                flag = check(gcda, gcda2, ind - 1) || check(gcda, gcda2, ind) || check(gcda, gcda2, ind + 1) || check(gcda, gcda2, min(ind + 2, n - 1));
        }
        else
        {
        }

        if (flag)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}