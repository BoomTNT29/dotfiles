#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main(void)
{
    ll t;
    cin >> t;

    while (t--)
    {
        ll n;
        cin >> n;

        vector<ll> a(n), b(n);
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (int i = 0; i < n; i++)
            cin >> b[i];

        ll m;
        cin >> m;

        multiset<ll> d;
        ll temp;
        for (int i = 0; i < m; i++)
        {
            cin >> temp;
            d.insert(temp);
        }

        bool flag = true;
        multiset<ll>::iterator itr;
        for (int i = 0; i < n && flag; i++)
        {
            if (b[i] != a[i])
                if ((itr = d.find(b[i])) != d.end())
                    d.erase(itr);
                else
                    flag = false;
            
            if (b[i] == temp)
                temp = -1;
        }

        if (temp != -1)
            flag = false;

        if (flag)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}