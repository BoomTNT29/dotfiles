#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var)         \
    for (auto &i : var)   \
    {                     \
        cout << i << " "; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    int n = 1;
    cin >> n;

    string s, ans = "";
    cin >> s;

    if (s[0] != '9')
        fr(i, n)
        {
            ans += '0' + ('9' - s[i]);
        }
    else
    {
        ll carry = 0;
        for (int i = n - 1; i > 0; i--)
        {
            if (s[i] > '1')
            {
                if (carry)
                    ans += ('1' + '9' - s[i]);
                else
                    ans += ('2' + '9' - s[i]);
                carry = 1;
            }
            else if (s[i] == '1')
            {
                if (carry)
                    ans += '9';
                else
                    ans += '0';
            }
            else
            {
                if (carry)
                    ans += '0';
                else
                    ans += '1';
                carry = 0;
                
            }
        }
        
        if (carry)
            ans += '1' + '9' - s[0];
        else
            ans += '2' + '9' - s[0];
        
        reverse(all(ans));
    }

    cout << ans;
    nl;
}

int main(void)
{
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}