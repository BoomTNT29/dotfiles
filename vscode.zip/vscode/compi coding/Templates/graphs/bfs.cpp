void BFS(vector<vector<pair<ll, ll>>> &adj_list, vector<ll> &p, ll src, ll n)
{
    vector<ll> v(n, 0);

    queue<ll> q;
    q.push(src);
    v[src] = 1;
    p[src] = -1;

    while (q.empty() == 0)
    {
        ll u = q.front();
        q.pop();

        for (auto &x : adj_list[u])
        {
            if (v[x.first] == 0)
            {
                q.push(x.first);
                p[x.first] = u;
                v[x.first] = 1;
            }
        }
    }
}