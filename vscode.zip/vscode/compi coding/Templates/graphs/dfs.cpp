void DFS(vector<vector<pair<ll, ll>>> &adj_list, vector<ll> &v, vector<ll> &p, ll src)
{
    v[src] = 1;
    for (auto &x : adj_list[src])
    {
        if (v[x.first] == 0)
        {
            p[x.first] = src;
            DFS(adj_list, v, p, x.first);
        }
    }
    
}