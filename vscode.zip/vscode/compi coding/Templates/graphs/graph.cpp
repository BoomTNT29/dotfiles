void read_adjList_dg(vector<vector<pair<ll, ll>>> &adj_list, int m) // its stored in the pair as node, wt
{
    ll s, t, w;
    for (int i = 0; i < m; i++)
    {
        cin >> s >> t >> w;
        adj_list[s].push_back(make_pair(t, w));
    }
}

void read_adjList_udg(vector<vector<pair<ll, ll>>> &adj_list, int m) // its stored in the pair as node, wt
{
    ll s, t, w;
    for (int i = 0; i < m; i++)
    {
        cin >> s >> t >> w;
        adj_list[s].push_back(make_pair(t, w));
        adj_list[t].push_back(make_pair(s, w));
    }
}