#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define fast_io                   \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    int n = 1;
    cin >> n;

    
}

int main(void)
{
    fast_io;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}