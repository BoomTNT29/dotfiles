#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << endl
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var, a)    \
    for (auto &i : var) \
    {                   \
        cout << i << a; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

struct segTree
{
    ll size;
    vll values;

    void init(ll n)
    {
        size = 1;
        while (size < n)
            size *= 2;
        values.resize(size * 2);
    }

    void build(vll &v)
    {
        fr(i, v.size())
        {
            values[size - 1 + i] = v[i];
        }

        for (int i = size - 2; i > -1; i--)
        {
            combine(i);
        }
    }

    void combine(ll index)
    {
        // combine values[2 * index + 1], values[2 * index + 2] and store the result in
        // values[i]
    }
};