#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;

//##################################ORDERED SET AND MULTISET########################################
#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp>     // Including tree_order_statistics_node_update
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
typedef tree<int, null_type, less_equal<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_multiset;
//##################################################################################################

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define vvll vector<vll>
#define fr(i, n) for (int i = 0; i < (n); i++)
#define rep(i, a, n) for (int i = (a); i <= (n); i++)
#define nl cout << "\n"
#define dbg(var) cout << #var << "=" << var << " "
#define dbgv(var)         \
    for (auto &i : var)   \
    {                     \
        cout << i << " "; \
    }
#define dbgvv(var)            \
    for (auto &i : var)       \
    {                         \
        for (auto &x : i)     \
        {                     \
            cout << i << " "; \
        }                     \
        nl;                   \
    }
#define all(v) v.begin(), v.end()
#define sz(v) (int)(v.size())
#define srt(v) sort(all(v))         // sort
#define mxe(v) *max_element(all(v)) // find max element in vector
#define mne(v) *min_element(all(v)) // find min element in vector
#define unq(v) v.resize(distance(v.begin(), unique(all(v))));

void solve(void)
{
    int n = 1;
    cin >> n;

    ordered_multiset x;

    x.insert(1);
    x.insert(1);
    x.insert(3);
    x.insert(5);
    x.insert(6);
    x.insert(3);

    // order is basically the number of elements that satisfy the cmp_fn
    cout << *x.find_by_order(1) << endl;            // 2
    cout << *x.find_by_order(3) << endl;            // 4
    cout << *x.find_by_order(5) << endl;            // 6
    cout << (end(x) == x.find_by_order(6)) << endl; // true

    cout << x.order_of_key(-1) << endl;  // 0
    cout << x.order_of_key(3) << endl;   // 2
    cout << x.order_of_key(6) << endl;   // 5
    cout << x.order_of_key(400) << endl; // 6

    cout << *x.lower_bound(3) << endl; // 5
    cout << *x.lower_bound(1) << endl; // 3

    cout << *x.upper_bound(3) << endl; // 5
    cout << *x.upper_bound(1) << endl; // 3
}

int main(void)
{
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}