from openpyxl import load_workbook


def readInputsFromExcel(filePath, header=False, sheet=0):
    try:
        wb = load_workbook(filename=filePath)
    except:
        print("File Error: Error while opening file.")
        return []

    if sheet == 0:
        ws = wb.active
    else:
        try:
            ws = wb[sheet]
        except:
            print("Sheet Error: Sheet name provided is wrong.")
            return []

    input_schedule = []

    try:
        if not header:
            for time, input in ws.rows:
                input_schedule.append((float(time.value), int(input.value)))
        else:
            rows = tuple(ws.rows)
            for x in range(1, len(rows)):
                input_schedule.append(
                    (float(rows[x][0].value), int(rows[x][1].value)))

    except:
        print("Data Error: File could not be read, data might be corrupt.")

    return input_schedule


print(readInputsFromExcel("test.xlsx"))
