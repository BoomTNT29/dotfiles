# https://openpyxl.readthedocs.io/en/stable/tutorial.html
# beautiful tutorial here

from openpyxl import load_workbook

wb = load_workbook(filename="grades.xlsx")
ws = wb.active  # takes the default sheet

# you can access other exisitng sheets like this:

# ws = wb["<sheet name>"]

# creating sheets is done using the .create_sheet() method, it takes the name and the position to make it as its parameters

# ws1 = wb.create_sheet('hiii', -1) # meaning the penultimate position (it is the default value)

# accessing and renaming a sheet title is done via the .title property of the worksheet

# ws.title = 'bluh'

# we can access the sheet names using the workbook attribute called sheetnames (it is in form of a list)

# we can access the different cells and rows quite easily, its pretty intuitive and easy to implement and play around, I'll just write the
# different ways we can use it.

ws['A4'] = 5
val = ws['A1']

d = ws.cell(row=1, column=2, value=4)

cell_range = ws['A1':'C2']
colC = ws['C']
col_range = ws['C:D']
row10 = ws[10]
row_range = ws[5:10]

# try looking into Worksheet.iter_rows() and Worksheet.iter_cols()

# using Worksheet.rows gives you a 2D tuple
# using Worksheet.columns gives you a 2D tuple
# can u guess the difference between the two tuples?
# using Worksheet.values gives you all the values the way you'd expect them to be in. (row wise)


for row in ws.values:
    for val in row:
        print(val)
