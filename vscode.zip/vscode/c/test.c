#include <stdio.h>

typedef long long int abc;

void main(void)
{
	abc l = 987;
	printf("%d %ld %lld\n", l, l, l);
}