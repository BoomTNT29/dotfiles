#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int x = 2;
    int y = 3;
    int x = x + y;
    vector<int> arr;
    // vector<DataType>arr is the way to define a list (python list) in cpp
    // also you can google it

    arr.push_back(5); // append
    arr.pop_back();

    int sz = arr.size(); // to get length of array
}