#include <stdio.h>
#include <string.h>

// docs of c: https://en.cppreference.com/w/

#define swap(a, b)  \
    {               \
        int *temp;  \
        *temp = *a; \
        *a = *b;    \
        *b = *temp; \
    }

typedef long long int abc;

int main()
{

    // the format codes for printf() for different data types is gives as follows
    //  %d or %i or %o or %x	- int
    //  %s - string
    //  %c - char
    //  %lf or %e - double
    //  %f - float
    //  %c - char
    //  %p - pointer
    //  %u - unsigned int

    printf("Hello World\n");

    int uninitialisedArrayOfInt[4];

    int initialisedArrayOfInt[] = {0, 1, 2, 3};

    // to find the length of an array use sizeof() (but this gives you the actual memory size of the array)
    // to overcome that we devide it by the size of the datatype of the element :)

    int len = sizeof(uninitialisedArrayOfInt) / sizeof(int);

    /*uninitialisedArrayOfInt[0] = 1;
    uninitialisedArrayOfInt[1] = 2;
    uninitialisedArrayOfInt[2] = 3;
    uninitialisedArrayOfInt[3] = 4;*/

    // alternatively using a for loop

    for (int i = 0; i < len; i++)
    {
        uninitialisedArrayOfInt[i] = i + 1;
        initialisedArrayOfInt[i] = i + 2;
    }

    // using a while loop to print

    int i = 0;

    while (i < len)
    {
        printf("%i\n", uninitialisedArrayOfInt[i]);
        i++;
    }

    // you can also create an array of array by simply doing
    int arr1[1][1];
    // how will you find number of columns and number of rows ^? ;P

    // to create a string in c, we create an array of strings
    // keep in mind you can also create a string by using char* as the data type

    // char *s = "Hello, World!";

    char str1[] = {'H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd', '!', '\0'}; // the \0 is a null terminating charecter that way c knows that you're string ends there or else your program might have undefined behavior
    printf("%s\n", str1);

    char str2[] = "Hello World!"; // here the null terminating charecter is implicit.
    printf("%s\n", str2);

    // the above two lines perform the same action
    // since they are basically arrays they're subjected to the same constraints and function of an array
    // give it a try yourself!

    // to find the size of a string you can do sizeof()-1 or
    int len2 = strlen(str1); // here the null terminating character is not counted
    printf("%i\n", len2);

    // you can also concatenate strings (join) using the strcat(s1, s2); function
    // it basically deletes s1 and creates s1 again with length of s1 + s2 + 1

    // strcat(str1, str2); // str1 is now "Hello World!Hello World!" //commented this since it corrupts data as the wrong implementaion of strcat()
    // printf("%s\n", str1);

    // you can copy a string into existing (empty) string provided that the destination string is atleast as big as the source string
    // or else your code will have undefined behavior

    char copycat[sizeof(str2)];
    strcpy(copycat, str2);
    printf("%s\n", copycat);

    // pointers are defined as such
    // dataType* nameOfPointer = &variableName; or dataType *nameOfPointer = &variableName;
    // the & operator aka reference operator is used to retrieve the location of a variable stored in the memory
    // you can reassign pointers as long as the type consistency is maintained
    // to print a pointer just use %p (format code)

    int *lenPtr = &len;
    printf("%p\n", lenPtr);

    // you can access the pointer's memory address's value by deferencing it
    // the dereference operator is *ptrName;
    // they can be reassigned too

    printf("%i\n", *lenPtr);
    *lenPtr = 200;
    printf("%i\n", len);

    // you can perform arthmetic operations on pointers (only + and -) if you add them by n the pointer moves to a new location that is
    //  n*sizeof(dataType) bytes forward

    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    int *ptr = &arr[0];
    ptr += 1; // don't use a value too high you might mess something up
    printf("%i\n", *ptr);

    // switch-case

    int number;
    printf("Enter a number: ");
    scanf("%d", &number);

    switch (number)
    {
    case 1:
        printf("cringe1\n");
        break;
    case 2:
        printf("cringe2\n");
        break;
    case 3:
        printf("cringe3\n");
        break;
    case 4:
        printf("cringe4\n");
        break;
    case 5:
        printf("cringe5\n");
        break;
    case 6:
        printf("cringe6\n");
        break;
    default:
        printf("defaulted\n");
        break;
    }

    // ternary operators

    number > 6 ? printf("numebr is indeed greater than 6\n") : printf("nvm\n");
    int YN;
    YN = number > 6 ? 5 : 6;
    printf("%d", YN);

    // to get user input from the same line as you run the c code in terminal
    // you can use the following peice of code

    //     void main(int number, char* array[]){
    //     for (int x=1; x < number; x++){
    //         printf("%s ", array[x]);
    //     }
    // }

    // for fun look into
    char *b[40];
    char(*c)[40];
}