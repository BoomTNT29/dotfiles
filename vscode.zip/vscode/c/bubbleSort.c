#include <stdio.h>

void printArr(int*, int);
void bubbleSort(int*, int);
void nthLargestElement(int*, int, int);

void main(){

    int arrSize;
    printf("What size of array do you want: ");
    scanf("%d", &arrSize);

    int arr[arrSize];

    for (int x=0; x<arrSize; x++){
        printf("%d element: ", x+1);
        scanf("%d", &arr[x]);
    }

    bubbleSort(arr, arrSize);

    printArr(arr, arrSize);

    int nthLargest;
    printf("Which largest element do you want to fine: ");
    scanf("%d", &nthLargest);

    nthLargestElement(arr, nthLargest, arrSize);

}

//nth largest element
void nthLargestElement(int* arr, int n, int size){
    printf("The %dth largest element is: %d\n", n, arr[size-n]);
}

//bubble sort
void bubbleSort(int* arr, int arrSize){
    int temp;
    for (int roundNum=0; roundNum<arrSize; roundNum++){
        for (int x=0; x<(arrSize-1); x++){
            if (arr[x] > arr[x+1]){
                temp = arr[x];
                arr[x] = arr[x+1];
                arr[x+1] = temp;
            }
        }
    }
}

//printing an array
void printArr(int* arr, int arrSize){
    for (int i=0; i<arrSize; i++){
        printf("%d\t", arr[i]);
    }
    printf("\n");
}