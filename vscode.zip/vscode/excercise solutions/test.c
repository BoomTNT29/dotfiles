#include <stdio.h>

int main(void){
    int y;
    int x = scanf("%d", &y);

    printf("%d, %d", x, y);
}