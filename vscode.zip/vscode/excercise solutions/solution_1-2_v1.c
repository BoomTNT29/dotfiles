#include <stdio.h>

void main(void){
    char puzzle[][4] = {
        {'t', 'h', 'i', 's'},
        {'w', 'a', 't', 's'},
        {'o', 'a', 'h', 'g'},
        {'f', 'g', 'd', 't'}
    };

    int widthOfPuzzle = 4;
    int lenghtOfPuzzle = 4;

    char wordsInPuzzle[][] = {}; //I give up
    
}