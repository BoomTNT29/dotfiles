#include <stdio.h>

void sort_in_decreasing(int*, int);
void add_element_at_pos(int*, int, int, int);
void printArr(int*, int);

void main(void){
    int arrSize;
    printf("Desired size of array: ");
    scanf("%d", &arrSize);

    int arr[arrSize];
    for (int x=0; x<arrSize; x++){
        printf("Element %d: ", x+1);
        scanf("%d", &arr[x]);
    }

    int nthLargest;
    do{
    printf("Which largest element do you want: ");
    scanf("%d", &nthLargest);
    } while (nthLargest > arrSize);

    //start of selection solution
    int finalArr[nthLargest]; //search if the memory is allocated during runtime properly
    for (int x=0; x<nthLargest; x++){
        finalArr[x] = arr[x];
    }

    sort_in_decreasing(finalArr, nthLargest);
    printArr(finalArr, nthLargest);

    for (int x=nthLargest; x<arrSize; x++){
        for (int i=0; i<nthLargest; i++){
            if (finalArr[i]<arr[x]){
                add_element_at_pos(finalArr, arr[x], i, nthLargest);
                break;
            }
        }
    }

    printf("The %d largest element is: %d", nthLargest, finalArr[nthLargest-1]);
}

void add_element_at_pos(int* arr, int value, int pos, int arrSize){
    for (int x=arrSize-1; x > pos; x--){
        arr[x] = arr[x-1];
    }
    arr[pos] = value;
    printArr(arr, arrSize);
}

void sort_in_decreasing(int* arr, int arrSize){
    int temp;
    for (int roundNum=0; roundNum<arrSize; roundNum++){
        for (int x=0; x<(arrSize-1); x++){
            if (arr[x] < arr[x+1]){
                temp = arr[x];
                arr[x] = arr[x+1];
                arr[x+1] = temp;
            }
        }
    }
}

void printArr(int* arr, int arrSize){
    for (int i=0; i<arrSize; i++){
        printf("%d\t", arr[i]);
    }
    printf("\n");
}