#include <stdio.h>

int getFileSize(FILE*);
int readFile(FILE*, char[], int);

int main(){
    
    FILE *fptr;

    fptr = fopen("textFile.txt", "r+");

    int bytes;
    int fileSizeInBytes = getFileSize(fptr);
    fseek(fptr, (long)0, 0); //Setting the pointer back to start of the file

    printf("The size of file opened is %d bytes\n", fileSizeInBytes);
    printf("How many bytes of content do you want to read: ");
    scanf("%d", &bytes);

    if (bytes > fileSizeInBytes) {
        printf("The file is smaller than the number of bytes you want to read!\n");

        return 1; //Ending the program, since the user gave the wrong input
    }

    char contents[bytes];

    readFile(fptr, contents, bytes);

    for (int x; x < sizeof(contents)/sizeof(char); x++){
        printf("%c", contents[x]);
    }
}

int readFile(FILE* fptr, char contents[], int bytesToRead){
    fread(contents, 1, bytesToRead, fptr);

    return 0; //The program executed wo any errors!
}

int getFileSize(FILE* fptr){
    int fileSize;

    while(!(feof(fptr))){
        fgetc(fptr);
        fileSize++;
    }
    
    printf("Completed reading file!\n");

    return fileSize;
}