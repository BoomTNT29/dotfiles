#include <stdio.h>
#include <math.h>

void printDigit(int);
int getSizeOfInt(int);
void printInteger(int, int);
void printFractionalPart(float);

void main(void){
    float num;
    printf("Enter any real number(10 digits max): ");
    scanf("%f", &num);

    int GIFofNum = abs((int)num); //converting double to an positive integer

    int negOrPos;
    if ((int)num < 0) { //checking if num is negative or positive
            negOrPos = 1;   //using 1 for negative and 0 for positive
        } else {
            negOrPos = 0;
        }

    if (fabs(num) - (float)GIFofNum == 0){ //checking if num is an integer
        
        printInteger(GIFofNum, negOrPos); //calling a funciton to print just an integer
        printf("\n");

    } else {
        int integer = abs((int)num); //just need the postive integer
        printInteger(integer, negOrPos); //printing just the integer part

        float fractionalPart = fabs(num) - (float)integer; //getting the fracitonal part

        printFractionalPart(fractionalPart); //printing the fractional part
        printf("\n");
    }
}

int getSizeOfInt(int num){
    int size = 0;
    do {
        num /= 10; //dividing by 10 basically deletes 1 digit at a time
        size++;
    } while(num != 0); //anything like 0.1 is taken as 0 since num is int type
    return size;
}

void printDigit(int digit){
    printf("%d", digit);
}

void printInteger(int num, int negOrPos){
    int size = getSizeOfInt(num); //getting size of integer (num of digits)
    int arr[size];
    
        for (int x=size-1; x>=0; x--){
            arr[x] = num % 10; //storing the remainder aka the units place digit in the array, but backwards
            num /= 10;         //deleting the units place digit since we dont require it anymore
        }
        
        if (negOrPos == 1){
            printf("-"); //making sure to print the negative sign
        }
        for (int x=0; x<size; x++){
            printDigit(arr[x]); //printing the array element by element
        }
}

void printFractionalPart(float fractionalPart){
    printf(".");
    do {
    fractionalPart *= 10; //extracting one decimal at a time
    printDigit((int)fractionalPart); //truncating all decimal part
    fractionalPart -= (int)fractionalPart; //removing the integer part
    } while (fractionalPart != 0); //stopping when all the decimal part is over
}