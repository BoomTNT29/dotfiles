problem 1.2 - haven't solved it yet
problem 1.3 - when inputs are decimals the resulting output is off by a very small number