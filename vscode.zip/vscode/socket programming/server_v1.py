import socket

host = "127.0.0.1"  # localhost
port = 8080  # never pick any reserver port: Like 80 as it is used by HTTP

# AF_INET = IPv4
# AF_INET6 = IPv6
# SOCK_STREAM = TCP
# SOCK_DGRAM = UDP
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print("Socket created successfully!")

# server is bind to host=127.0.0.1 and running on port=8080
server.bind((host, port))
print(f"Server is running on {host}:{port}")

# server is listening for incoming connections from any client
# client can use server's IP address(127.0.0.1) & PORT(8080) to connect
server.listen()
print(f"Server is listening for incoming connections on {host}:{port}...")


def receiveAndSend(client):
    while True:
        try:
            response = client.recv(1024)
            print(f"Message received from client: {response.decode('ascii')}")

            message = input("Enter a message to send to the client: ")
            client.send(message.encode("ascii"))
        except:
            print("An error occurred!")
            client.close()
            break


if __name__ == "__main__":
    # each time a client connects to the server, server will accept the connection
    client, address = server.accept()
    print(f"Connected with {str(address)}")

    # inform the client about a successful connection
    client.send("Connected to the server!".encode("ascii"))

    receiveAndSend(client)
