import socket
import threading

host = "127.0.0.1"  # localhost
port = 8080  # never pick any reserver port: Like 80 as it is used by HTTP

# AF_INET = IPv4
# AF_INET6 = IPv6
# SOCK_STREAM = TCP
# SOCK_DGRAM = UDP
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print("Socket created successfully!")

# server is bind to host=127.0.0.1 and running on port=8080
server.bind((host, port))
print(f"Server is running on {host}:{port}")

# server is listening for incoming connections from any client
# client can use server's IP address(127.0.0.1) & PORT(8080) to connect
server.listen()
print(f"Server is listening for incoming connections on {host}:{port}...")

# clients[i] will have nickname -> nicknames[i]
clients = []
nicknames = []


def broadcast(message):
    for client in clients:
        client.send(message)


# whenever server receives a message from a client, it will broadcast it to all other clients
def handle(client):
    while True:
        try:
            message = client.recv(1024)
            broadcast(message)
        except:
            index = clients.index(client)
            clients.remove(client)
            client.close()
            nickname = nicknames[index]
            nicknames.remove(nickname)

            broadcast(f"{nickname} left the chat!".encode("ascii"))
            break


if __name__ == "__main__":
    while True:
        # each time a client connects to the server, server will accept the connection
        client, address = server.accept()
        print(f"Connected with {str(address)}")

        # server will ask the client to provide a nickname
        client.send("NICK?".encode("ascii"))
        nickname = client.recv(1024).decode("ascii")

        # server will store the client and nickname
        clients.append(client)
        nicknames.append(nickname)

        # inform the client about a successful connection
        print(f"Nickname of the client is {nickname}")
        client.send("Connected to the server!".encode("ascii"))

        # broadcast the new client's nickname to all other clients
        broadcast(f"{nickname} joined the chat!".encode("ascii"))

        # ? start a new thread for each client
        thread = threading.Thread(target=handle, args=(client,))
        thread.start()
