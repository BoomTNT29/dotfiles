import socket
import threading

nickname = input("Choose a nickname to join the chatroom: ")

server_ip_address = "127.0.0.1"  # localhost
server_port = 8080  # server is listening for active TCP connections on this port

# AF_INET = IPv4
# AF_INET6 = IPv6
# SOCK_STREAM = TCP
# SOCK_DGRAM = UDP
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect((server_ip_address, server_port))


def receive():
    while True:
        try:
            message = client.recv(1024).decode("ascii")

            if message == "NICK?":
                client.send(nickname.encode("ascii"))
            else:
                print(message)
        except:
            print("An error occurred!")
            client.close()
            break


def write():
    while True:
        message = input("")
        if message == "exit":
            client.close()
            break
        else:
            message = f"{nickname}: {message}"
            client.send(message.encode("ascii"))


if __name__ == "__main__":
    receive_thread = threading.Thread(target=receive)
    receive_thread.start()

    write_thread = threading.Thread(target=write)
    write_thread.start()
