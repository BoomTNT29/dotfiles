import socket
import threading

server_ip_address = "127.0.0.1"  # localhost
server_port = 8080  # server is listening for active TCP connections on this port

# AF_INET = IPv4
# AF_INET6 = IPv6
# SOCK_STREAM = TCP
# SOCK_DGRAM = UDP
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect((server_ip_address, server_port))


def receiveAndSend():
    while True:
        try:
            response = client.recv(1024)
            print(f"Message received from server: {response.decode('ascii')}")

            message = input("Enter a message to send to the server: ")
            client.send(message.encode("ascii"))
        except:
            print("An error occurred!")
            client.close()
            break


if __name__ == "__main__":
    receiveAndSend()
