import discord
import os
import requests

TOKEN = os.getenv('TOKEN')


class MyClient(discord.Client):
    def __init__(self, *, intents=discord.Intents.default(), **options):
        super().__init__(intents=intents, **options)

    async def on_ready(self):
        """
        Does the following whenever bot starts up.
        """
        print(f"We have logged in as {self.user}")

    async def on_message(self, message: discord.Message):
        """
        Does the following everytime there is a message on the server.
        """
        if (message.author == self.user):
            return

        embed = embedMessage(
            title='Example Embed',
            description='This is an example of an embedded message.',
            # colour=discord.Colour.red(),
            url='https://google.com',
            timestamp=message.created_at
        )

        embed.set_thumbnail(
            url='https://w7.pngwing.com/pngs/187/537/png-transparent-harry-potter-computer-icons-kitu-harry-potter-artwork-wing-symbol.png')
        embed.set_author(
            name='Author Name', icon_url='https://w7.pngwing.com/pngs/187/537/png-transparent-harry-potter-computer-icons-kitu-harry-potter-artwork-wing-symbol.png')
        embed.set_footer(
            text='Footer Text', icon_url='https://w7.pngwing.com/pngs/187/537/png-transparent-harry-potter-computer-icons-kitu-harry-potter-artwork-wing-symbol.png')
        embed.set_image(
            url='https://w7.pngwing.com/pngs/187/537/png-transparent-harry-potter-computer-icons-kitu-harry-potter-artwork-wing-symbol.png')

        embed.add_field(name='Field 1', value='Value 1', inline=False)
        embed.add_field(name='Field 2', value='Value 2', inline=True)
        embed.add_field(name='Field 3', value='Value 3', inline=True)

        # Send the embedded message
        await message.channel.send(embed=embed)
        print(message.content)

        await message.channel.send("https://giphy.com/gifs/warnerbrosde-harry-potter-phantastische-tierwesen-dumbledores-geheimnisse-zEvwh3NJBpqMoVj96q")

# *, colour=None, color=None, title=None, type='rich', url=None, description=None, timestamp=None, footer=None, image=None, thumbnail=None, video=None, provider=None, author=None, fields=None, inline=True, file=None, view=None


class embedMessage(discord.Embed):
    def __init__(
        self,
        *,
        colour=None,
        color=None,
        title=None,
        type='rich',
        url=None,
        description=None,
        timestamp=None,
        footer=None,
        image=None,
        thumbnail=None,
        video=None,
        provider=None,
        author=None,
        fields=None,
        inline=True,
        file=None,
        view=None
    ):
        super().__init__(colour=colour, color=color, title=title, type=type,
                         url=url, description=description, timestamp=timestamp)

        # self.colour = colour
        # self.color = color
        # self.title = title
        # self.type = type
        # self.url = url
        # self.description = description
        # self.timestamp = timestamp

        if (self.footer):
            self.set_footer(text=self.footer)

        if (self.image):
            self.set_image(url=self.image)

        if (self.thumbnail):
            self.set_thumbnail(url=self.thumbnail)

        if (self.author):
            self.set_author(name=self.author)

        if (self.fields):
            for field in self.fields:
                self.add_field(
                    name=field['name'], value=field['value'], inline=self.inline)


bot = MyClient()
bot.run(TOKEN)
