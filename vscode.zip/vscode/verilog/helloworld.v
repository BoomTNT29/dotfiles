// introduction to verilog!!
module new();
    initial
    begin
        $display("Hello, World!");
        $finish;
    end
endmodule

// we use "begin" and "end" as brackets just like in C
// the $display is like a print statement for the user and has no actual meaning in the working
// of the system.

//---Blocking and non blocking statemetns
// = is a blocking statement and <= is a non blocking statement
// as a general thumb of rule the blocking statements are executed first
// then the non blocking statements are executed at a later point of time

// module L;
//         parameter a = 3; // immideately executed
//         parameter b = 4; // immideately executed
//         parameter c = 0;
    
//     initial
//     begin
//         a <= 3 + 4; // will be executed at a later point of time
//         c = a; // immideately executed *DOES NOT WAIT FOR THE EXECUTION OF THE PREVIOUS STATEMENT*
//         $display("The value of a:");
//         $display(a);
//         $finish;
//     end
// endmodule

// there is a difference in defining reg / wires wtv
// for example
// reg A[4:0]
// reg A[0:4] are different in computation
// In the first case the first bit is the most significant since its referred to as 4, while in the second one
// the last bit is the most significant since its referred to as 4.
// but in verilog implementation it does not make a difference since we access it with indices anyway.

// $setup and $hold tasks are used to check the setup and hold constraints for a sequenctial element in the design. In a sequential element
// such as an edge triggered flip flop the setup time is the minimum time the data must arrive before the active edge. The hold time
// is the minimum time the data cannot change after the active clock edge.

// Usage:
// $hold (reference_event, data_event, limit);
// explaination:
// reference_event: Signal that establishes a referece for monitoring the data_event signal.
// data_event: Signal that is meant for visualisation.
// limit: Minimum time required for hold of data event.
// voilation is reported if (Tdata_event - Treference_event) < limit.

// $width(reference_event, limit);
// The system task is used to check that the width of a pulse meets the minimum width requirement.

// # is used as delay, usage: # 5
// @ is used as a delay but here we wait for a change
// usage: @ (events, events, ..)
// wait is used to wait until the exp is satisfied
// usage: wait (exp)

// In represetation fo structural description code
// and # delay instance_name(out, input, input, ...), instance_name2(out, input, input, ..), ...;